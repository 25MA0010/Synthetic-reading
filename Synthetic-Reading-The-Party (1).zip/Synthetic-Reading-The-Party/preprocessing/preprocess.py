#!/usr/bin/env python3
"""
preprocess.py -- Step 3: text cleaning and preprocessing
Synthetic Reading: The Party by Sayantani Dasgupta

Works locally and in Google Colab (Python 3.8+). Only the standard library is required.
Usage (from repository root):
    python preprocessing/preprocess.py
Outputs (results/):  corpus_blocks.json, sentences.csv, word_frequencies.csv, corpus_summary.json
The Step 1 passages are taken from the highlighted document by partial_reading/extract_highlights.py.

Design choices (literary context is preserved):
* Paragraph boundaries are kept: each paragraph is a unit with an ID (B<block>P<n>).
* Only layout noise is cleaned (extra whitespace, stray spaces before punctuation, spaced-out
  abbreviations like "T V", "P D A", "O B G Y N", "T M I" are re-joined).
* Original wording, capitalisation and curly quotes are retained in the clean text.
  Lower-casing happens ONLY in the token layer used for frequencies.
* NO indiscriminate stopword removal: the stopword list is tiny and function-word only, and
  deliberately excludes pronouns "you/your" (second-person address is analytically important),
  gender terms (man, woman, wife, husband...), desire/emotion words and negations.
"""
import csv, json, re, collections, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
CORPUS = os.path.join(ROOT, 'corpus', 'The_Party.txt')
RESULTS = os.path.join(ROOT, 'results')

SPACED_ABBR = {'T V': 'TV', 'P D A': 'PDA', 'O B G Y N': 'OBGYN', 'T M I': 'TMI'}
# Function words only. Deliberately NOT removed: you/your, he/she/her/his, man/woman, not/no, etc.
MINIMAL_STOPWORDS = {'a','an','the','and','or','of','to','in','on','at','for','with','as','by','is','are',
                     'was','were','be','been','it','its','that','this','these','those','than','then','so'}

def clean_text(s):
    s = re.sub(r'[\u00a0\u2009\u200a\u202f\u2002\u2003]', ' ', s)   # hair/thin/non-breaking spaces from the source -> normal space
    for k, v in SPACED_ABBR.items():
        s = s.replace(k, v)
    s = re.sub(r'\s+([!?.,;:])', r'\1', s)      # "sucker !" -> "sucker!"
    s = re.sub(r'[ \t]+', ' ', s).strip()
    return s

def load_blocks(path=CORPUS):
    """Return {block_id: [paragraph, ...]} from the marker-delimited corpus file."""
    blocks, cur = {}, None
    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')
            m = re.match(r'\[\[BLOCK (\d)\]\]', line)
            if m:
                cur = int(m.group(1)); blocks[cur] = []
            elif cur and line.strip():
                blocks[cur].append(clean_text(line))
    return blocks

ABBR = ('Mr','Mrs','Ms','Dr','St')
def split_sentences(par):
    """Rule-based segmentation that keeps quotation marks with their sentence."""
    parts = re.split(r'(?<=[.!?])["”’]?\s+(?=["“‘]?[A-Z])', par)
    return [p.strip() for p in parts if p.strip()]

def tokenize(s):
    return re.findall(r"[a-z]+(?:['’][a-z]+)?", s.lower())

def main():
    os.makedirs(RESULTS, exist_ok=True)
    blocks = load_blocks()
    rows, summary, freq_all, freq_by_block, out_blocks = [], {}, collections.Counter(), {}, {}
    for b, pars in blocks.items():
        out_blocks[b] = []
        fb = collections.Counter()
        for pi, par in enumerate(pars, 1):
            pid = f'B{b}P{pi}'
            sents = split_sentences(par)
            toks = tokenize(par)
            out_blocks[b].append({'paragraph_id': pid, 'text': par, 'n_sentences': len(sents), 'n_tokens': len(toks)})
            for si, s in enumerate(sents, 1):
                rows.append({'block': b, 'paragraph_id': pid, 'sentence_no': si, 'sentence': s, 'n_tokens': len(tokenize(s))})
            kept = [t for t in toks if t not in MINIMAL_STOPWORDS]
            fb.update(kept)
        freq_by_block[b] = fb; freq_all.update(fb)
        summary[b] = {'paragraphs': len(pars), 'sentences': sum(p['n_sentences'] for p in out_blocks[b]),
                      'words_whitespace': sum(len(p.split()) for p in pars),
                      'tokens': sum(p['n_tokens'] for p in out_blocks[b])}
    summary['total'] = {k: sum(summary[b][k] for b in blocks) for k in summary[1]}
    json.dump({str(b): v for b, v in out_blocks.items()}, open(os.path.join(RESULTS, 'corpus_blocks.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    json.dump({str(k): v for k, v in summary.items()}, open(os.path.join(RESULTS, 'corpus_summary.json'), 'w'), indent=1)
    with open(os.path.join(RESULTS, 'sentences.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    with open(os.path.join(RESULTS, 'word_frequencies.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(['word', 'total'] + [f'block{b}' for b in blocks])
        for word, n in freq_all.most_common():
            w.writerow([word, n] + [freq_by_block[b][word] for b in blocks])

    print(json.dumps({str(k): v for k, v in summary.items()}, indent=1))

if __name__ == '__main__':
    main()
