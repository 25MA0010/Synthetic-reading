#!/usr/bin/env python3
"""
appetite_check.py -- Step 7 supporting check (NOT evidence of a theme).
Synthetic Reading: The Party by Sayantani Dasgupta

Question tested: Fig. 5 shows that class and sexuality share 0 evidence items in the coding scheme.
The Step 7 close reading argues that the two meet through the language of appetite (eating, hunger,
mouths, swallowing). Is that visible as a simple lexical pattern, or does it rest on a few figurative
passages that only close reading can identify?

Method: a small, documented appetite lexicon is matched against every paragraph of the clean corpus.
We then compare the share of paragraphs containing appetite vocabulary in (a) the whole story and
(b) paragraphs cited as evidence for each dimension in results/theme_extraction.json.

Run from repo root:  python interpretation/appetite_check.py
Writes results/step7_appetite_check.json
"""
import json, os, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
C = json.load(open(os.path.join(ROOT, 'results', 'corpus_blocks.json'), encoding='utf-8'))
T = json.load(open(os.path.join(ROOT, 'results', 'theme_extraction.json'), encoding='utf-8'))
VOCAB = T['metadata']['theme_vocabulary']

LEXICON = ['hungry', 'hunger', 'stomach', 'appetite', 'eat', 'eating', 'ate', 'food', 'biryani', 'chips', 'snack', 'snacks',
           'ravenous', 'lustful', 'swallow', 'taste', 'tastes', 'tasted', 'mouth', 'mouths', 'greed', 'bite', 'bites', 'fed', 'feed',
           'platter', 'platters', 'pakoras', 'samosas', 'jalebis', 'sandwich', 'sandwiches', 'meat', 'rice', 'onion', 'onions',
           'kitchen', 'cook', 'cooking', 'cooked', 'drink', 'drinking', 'vodka', 'ice']
RX = re.compile(r'\b(' + '|'.join(sorted(LEXICON, key=len, reverse=True)) + r')\b', re.I)

paras = {p['paragraph_id']: p['text'] for blk in C.values() for p in blk}
hit = {pid for pid, t in paras.items() if RX.search(t)}

cited = {}
for b in T['blocks']:
    for th in b['major_themes']:
        for e in th['evidence']:
            cited.setdefault(e['paragraph_id'], set()).add(th['theme_id'])

def dims_of(tids):
    return {d for t in tids for d in VOCAB[t]['dimensions']}

order = lambda pid: (int(pid[1]), int(pid[3:]))
out = {'lexicon': LEXICON, 'paragraphs_total': len(paras), 'paragraphs_with_appetite_words': len(hit),
       'share_whole_story': round(len(hit) / len(paras), 3), 'by_dimension': {}}
for d in ('gender', 'sexuality', 'class', 'emotional_vulnerability'):
    ps = sorted((p for p, ts in cited.items() if d in dims_of(ts)), key=order)
    h = [p for p in ps if p in hit]
    out['by_dimension'][d] = {'cited_paragraphs': len(ps), 'with_appetite_words': len(h), 'share': round(len(h) / len(ps), 3) if ps else None,
                              'paragraph_ids_with_appetite_words': h}
out['reading'] = ('Appetite vocabulary is spread across about half of the story, and sexuality-coded paragraphs contain it at almost '
                  'exactly the base rate. Frequency therefore cannot show a link between appetite and desire; the link argued in '
                  'Step 7 rests on a few figurative transfers that close reading has to identify.')
json.dump(out, open(os.path.join(ROOT, 'results', 'step7_appetite_check.json'), 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
print(f"appetite words in {len(hit)}/{len(paras)} paragraphs ({out['share_whole_story']:.0%})")
for d, v in out['by_dimension'].items():
    print(f"  {d:24s} {v['with_appetite_words']}/{v['cited_paragraphs']} cited paragraphs ({v['share']:.0%})")
