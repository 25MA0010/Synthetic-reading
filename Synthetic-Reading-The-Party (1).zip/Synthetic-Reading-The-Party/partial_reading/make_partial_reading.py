#!/usr/bin/env python3
"""
make_partial_reading.py -- Step 1: writes the partial-reading record.
Builds partial_reading/partial_reading.txt and partial_observations.json from
selected_passages.json (the highlighted passages, extracted by extract_highlights.py).

The observations below are first impressions formed from the highlighted passages ONLY.
For each block they also check which of the researcher's key words are already visible in
those passages and which come only from the rest of the block.
Run from the repository root:  python partial_reading/make_partial_reading.py
"""
import json, os

R = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
sel = json.load(open(os.path.join(R, 'partial_reading', 'selected_passages.json'), encoding='utf-8'))

OBS = {
 '1': {
  'observations': ("The second-person, present-tense voice puts the reader inside a reluctant guest. She goes out of obligation, not friendship: "
                   "the host isn’t 'really a friend friend', and she cares 'neither for the occasion nor the husband'. Class is felt "
                   "through place: the hosts' bungalow near Hauz Khas market against her solitary home in the 'hinterlands', all she "
                   "can afford on her salary. Food (the dhaba biryani, imagined platters from vendors) is already a sign of comfort and of "
                   "dependence. The rule not to disturb the widowed mother downstairs suggests a household with its own hierarchy."),
  'themes': ['Class envy and economic insecurity', 'Obligation and superficial sociability', 'Loneliness and distance from former colleagues', 'Food as comfort and status'],
  'keywords_visible': ['Social inequality', 'Class consciousness', 'Economic insecurity', 'Social status', 'Material privilege',
                       'Loneliness and alienation', 'Workplace relationships', 'Superficial social interactions'],
  'keywords_later': ['Gender expectations', 'Insecurity and self-consciousness'],
 },
 '2': {
  'observations': ("The men talk philosophy (Auro on Nietzsche, Mahesh sighing 'dramatically') while the women watch: Tanu with 'the ardor "
                   "of a devotee', Rani 'as if in a daze'. Male talk is a performance with a female audience, and two women's gazes on "
                   "one man hint at attraction and rivalry. The narrator stands outside this circle, tired and hungry, and nobody offers "
                   "her a drink or food. The broken fridge and 'no ice' in an April in New Delhi make the hosts' hospitality look careless."),
  'themes': ['Male intellectual performance', 'Devotion and attraction (Tanu, Rani)', 'Exclusion and loneliness', 'Hunger and failed hospitality'],
  'keywords_visible': ['Jealousy and attraction', 'Loneliness'],
  'keywords_later': ['Sexual identity', 'Repressed desire', 'Same-sex relationships', 'Heteronormativity', 'Internalised prejudice',
                     'Sexual anxiety', 'Emotional confusion', 'Social conditioning'],
 },
 '3': {
  'observations': ("A remembered fight between Pia and Projapoti (money, chores, mothers) and their quick move into a shared flat show a "
                   "same-sex couple living openly and stormily. The narrator keeps her distance ('Why put yourself through additional "
                   "discomfort'), yet notices Pia's body closely. Mahesh decides when dinner begins, with a theatrical smack of the knee. "
                   "Though hungry and tired, the narrator offers to help 'before you can stop yourself': being 'too well brought up' "
                   "overrides her own needs."),
  'themes': ['People-pleasing and upbringing', 'Male control of the evening', 'Discomfort with (and attention to) a same-sex couple', 'Hunger and waiting'],
  'keywords_visible': ['Male dominance', 'Power imbalance', 'People-pleasing behaviour', 'Social conformity', 'Unfulfilled desire'],
  'keywords_later': ['Gender stereotypes', 'Emotional dependency', 'Patriarchal relationships', 'Childhood trauma', 'Self-worth'],
 },
 '4': {
  'observations': ("Auro's low question ('What are you doing afterwards?') leaves the narrator 'fearful and desperate at the same time'. "
                   "Mahesh cuts in and tells her she has to stay; she agrees 'automatically', with a bitter taste in her mouth, and answers "
                   "her mother in her head: 'No, Ma, I was not spineless.' A past accusation is at work in the present. The long-awaited "
                   "biryani is a disappointment: overcooked, undercooked and over-salted. Hunger has turned into lost appetite."),
  'themes': ['Desire and fear (Auro)', 'Compliance under male pressure', "A mother's judgement still at work", 'Disappointment'],
  'keywords_visible': ['Jealousy and insecurity', 'Power of speech', 'Emotional manipulation'],
  'keywords_later': ['Hidden relationships', 'Truth and disclosure', 'Betrayal', 'Sexual identity', 'Moral conflict',
                     'Emotional confrontation', 'Consequences of honesty'],
 },
}

st = sel['stats']
lines = ['PARTIAL READING RECORD -- The Party (Sayantani Dasgupta)', '=' * 64,
         'Method: ' + sel['method'],
         f"Coverage: {st['total']['words_selected']} of {st['total']['words_in_block']} words ({st['total']['share_of_words']:.0%}).",
         'Observations are first impressions formed from the highlighted passages only.', '']
for b in '1234':
    s = st[b]
    lines += [f"BLOCK {b}  ({s['paragraphs_selected']} of {s['paragraphs_in_block']} paragraphs, {s['words_selected']} of {s['words_in_block']} words, {s['share_of_words']:.0%})", '-' * 64]
    lines += [f"[{p['paragraph_id']}] {p['text']}" for p in sel['sample'][b]]
    o = OBS[b]
    lines += ['Initial observations: ' + o['observations'],
              'Preliminary themes: ' + '; '.join(o['themes']),
              "Researcher's key words already visible in these passages: " + '; '.join(o['keywords_visible']),
              "Researcher's key words that come only from the rest of the block: " + '; '.join(o['keywords_later']), '']
open(os.path.join(R, 'partial_reading', 'partial_reading.txt'), 'w', encoding='utf-8').write('\n'.join(lines))
json.dump(OBS, open(os.path.join(R, 'partial_reading', 'partial_observations.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('partial_reading.txt and partial_observations.json written')
