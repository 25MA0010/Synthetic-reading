#!/usr/bin/env python3
"""
extract_highlights.py -- Step 1: the partial reading.
Synthetic Reading: The Party by Sayantani Dasgupta

The researcher's document (source/The_Party_divided_into_4_blocks.docx) marks the passages read for the
partial reading with yellow highlighting. This script reads those highlights directly from the .docx
(standard library only), maps each highlighted paragraph to its paragraph ID in the clean corpus,
checks that the text matches, and writes partial_reading/selected_passages.json.

Run from the repository root, after preprocessing/preprocess.py:
    python partial_reading/extract_highlights.py
"""
import json, os, re, zipfile
from xml.etree import ElementTree as ET

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
DOCX = os.path.join(ROOT, 'source', 'The_Party_divided_into_4_blocks.docx')
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'

corpus = json.load(open(os.path.join(ROOT, 'results', 'corpus_blocks.json'), encoding='utf-8'))
SPACED_ABBR = {'T V': 'TV', 'P D A': 'PDA', 'O B G Y N': 'OBGYN', 'T M I': 'TMI'}

def norm(s):
    s = re.sub(r'[      ]', ' ', s)
    for k, v in SPACED_ABBR.items():
        s = s.replace(k, v)
    s = re.sub(r'\s+([!?.,;:])', r'\1', s)
    return re.sub(r'\s+', ' ', s).strip()

root = ET.fromstring(zipfile.ZipFile(DOCX).read('word/document.xml'))
paras = []
for p in root.iter(W + 'p'):
    text, hl = '', ''
    for r in p.iter(W + 'r'):
        t = ''.join(x.text or '' for x in r.iter(W + 't'))
        text += t
        if r.find(f'{W}rPr/{W}highlight') is not None:
            hl += t
    paras.append((text, hl))

# Story paragraphs sit between the headings "Block n — approximately ... words" and the next blank line/heading.
selected, block, k = {}, None, 0
for text, hl in paras:
    m = re.match(r'Block ([1-4]) — approximately', text.strip())
    if m:
        block, k = m.group(1), 0
        continue
    if block is None or not text.strip():
        if block and not text.strip() and k:
            block = None          # blank line ends the block's story text
        continue
    k += 1
    if k > len(corpus[block]):
        block = None
        continue
    if block == '1' and k == 1:   # title and byline share the first paragraph in the document
        text = text.split('Sayantani Dasgupta', 1)[-1]
    clean = corpus[block][k - 1]
    assert norm(text) == clean['text'], f'paragraph mismatch at Block {block}, paragraph {k}'
    if hl.strip():
        covered = len(norm(hl)) / len(clean['text'])
        assert covered > 0.98, f'{clean["paragraph_id"]}: only part of the paragraph is highlighted ({covered:.0%})'
        selected.setdefault(block, []).append({'paragraph_id': clean['paragraph_id'], 'text': clean['text']})

stats = {}
for b in '1234':
    words_sel = sum(len(p['text'].split()) for p in selected[b])
    words_all = sum(len(p['text'].split()) for p in corpus[b])
    stats[b] = {'paragraphs_selected': len(selected[b]), 'paragraphs_in_block': len(corpus[b]),
                'words_selected': words_sel, 'words_in_block': words_all, 'share_of_words': round(words_sel / words_all, 3)}
tot_sel = sum(v['words_selected'] for v in stats.values()); tot_all = sum(v['words_in_block'] for v in stats.values())
stats['total'] = {'words_selected': tot_sel, 'words_in_block': tot_all, 'share_of_words': round(tot_sel / tot_all, 3)}

out = {'method': 'Passages highlighted in yellow in the researcher\'s document (source/The_Party_divided_into_4_blocks.docx): '
                 'the opening passage of each block, read before the rest of the story.',
       'stats': stats, 'sample': selected}
json.dump(out, open(os.path.join(ROOT, 'partial_reading', 'selected_passages.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for b in '1234':
    s = stats[b]
    print(f"Block {b}: {', '.join(p['paragraph_id'] for p in selected[b])}  ({s['words_selected']}/{s['words_in_block']} words, {s['share_of_words']:.0%})")
print(f"Total: {tot_sel}/{tot_all} words ({stats['total']['share_of_words']:.0%})")
