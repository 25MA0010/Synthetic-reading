#!/usr/bin/env python3
"""
extract_human_interpretation.py -- the researcher's full-text (human) interpretation.
Synthetic Reading: The Party by Sayantani Dasgupta

Reads the "Human Interpretation" section of source/The_Party_divided_into_4_blocks.docx (standard library only)
and writes results/human_interpretation.json, keeping the researcher's wording and structure:
per block (title, main focus, paragraphs, "Human interpretation", "Connection to research question") and the
overall interpretation. Only two kinds of material are left out: stray file-name markers
("The_Party_divided_into_4_blocks") and two sentences addressed to the reader of the document ("your ... analysis",
"your document"), which comment on the document rather than on the story.

Run from the repository root:  python extraction/extract_human_interpretation.py
"""
import json, os, re, zipfile
from xml.etree import ElementTree as ET

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
DOCX = os.path.join(ROOT, 'source', 'The_Party_divided_into_4_blocks.docx')
OUT = os.path.join(ROOT, 'results', 'human_interpretation.json')
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
MARKER = 'The_Party_divided_into_4_blocks'

root = ET.fromstring(zipfile.ZipFile(DOCX).read('word/document.xml'))
paras = []
for p in root.iter(W + 'p'):
    t = ''
    for el in p.iter():
        if el.tag == W + 't': t += el.text or ''
        elif el.tag == W + 'br': t += '\n'
    t = t.replace(MARKER, '').strip()
    is_list = p.find(f'{W}pPr/{W}numPr') is not None
    paras.append((t, is_list))

start = next(i for i, (t, _) in enumerate(paras) if t == 'Human Interpretation of the Four Blocks')
data = {'source': 'source/The_Party_divided_into_4_blocks.docx, section "Human Interpretation"', 'blocks': {}, 'overall': []}
section = None
for t, is_list in paras[start + 1:]:
    if not t:
        continue
    if t.startswith('Research questions'):
        break
    m = re.match(r'Block ([1-4]) — (.+)$', t)
    if m and '\n' not in t:
        section = data['blocks'].setdefault(m.group(1), {'title': m.group(2), 'items': []})['items']
        continue
    if t == 'Overall Human Interpretation':
        section = data['overall']
        continue
    if 'your human–AI' in t or 'in your document' in t:      # remarks addressed to the document's reader
        continue
    if is_list:
        if section and section[-1]['kind'] == 'list':
            section[-1]['items'].append(t)
        else:
            section.append({'kind': 'list', 'items': [t]})
        continue
    lab = re.match(r'(Main focus|Human interpretation|Connection to research question):\s*(.+)$', t, re.S)
    if lab:
        section.append({'kind': 'labelled', 'label': lab.group(1), 'text': lab.group(2).strip()})
    elif '\n' in t:
        lines = [x.strip() for x in t.split('\n') if x.strip() and x.strip() != '↓']
        section.append({'kind': 'lines', 'items': lines})
    elif section is data['overall'] and len(t) < 60 and not t.endswith(('.', ':')):
        section.append({'kind': 'heading', 'text': t})
    else:
        section.append({'kind': 'p', 'text': t})

assert sorted(data['blocks']) == ['1', '2', '3', '4'] and data['overall'], 'interpretation section not found'
json.dump(data, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('human_interpretation.json written:', {b: len(v['items']) for b, v in data['blocks'].items()}, 'overall', len(data['overall']))
