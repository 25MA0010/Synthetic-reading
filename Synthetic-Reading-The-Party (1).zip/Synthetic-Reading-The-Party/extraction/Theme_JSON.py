#!/usr/bin/env python3
"""
Theme_JSON.py -- Step 5: structured theme extraction + programmatic validation.
Synthetic Reading: The Party by Sayantani Dasgupta

TWO SOURCES OF EXTRACTION (be explicit about which one you used):

1. source = "annotated"  (default)
   The AI-generated extraction below (ANNOTATIONS) was produced by Claude (claude-sonnet-5-5) in a
   chat session on 2026-11-06 by reading the complete corpus under the rules of prompts/prompt.txt.
   It is NOT the output of a specialised local LLM. Every quotation is machine-verified against
   corpus/The_Party.txt by this script; anything that fails verification stops the build.

2. source = "local-llm"
   Sends prompts/prompt.txt + the corpus to a local Ollama server (http://localhost:11434) and validates
   the reply with the same checks. Not executed in the original build (no local LLM was available there).
   Usage:  python extraction/Theme_JSON.py --source local-llm --model llama3.1:8b
   Output is written to results/theme_extraction_llm.json (it never overwrites the annotated file).

Human-generated themes are the researcher's own keyword lists (copied from her document, unchanged).
Her "Human Interpretation" (full-text) section is extracted by extract_human_interpretation.py and coded to canonical themes below.

Run from the repository root:  python extraction/Theme_JSON.py
"""
import argparse, json, os, re, sys, urllib.request

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
CORPUS = os.path.join(ROOT, 'corpus', 'The_Party.txt')
PROMPT = os.path.join(ROOT, 'prompts', 'prompt.txt')
OUT = os.path.join(ROOT, 'results', 'theme_extraction.json')

# ----------------------------------------------------------------------------------------------
# Canonical theme vocabulary (used so human and AI themes can be compared).
# dimensions: g=gender, s=sexuality, c=class, e=emotional vulnerability
# ----------------------------------------------------------------------------------------------
THEMES = {
 'T01': ('Class consciousness and economic insecurity', ['class']),
 'T02': ('Alienation and social exclusion', ['emotional_vulnerability', 'class']),
 'T03': ('Superficial sociability and performed goodness', ['class']),
 'T04': ('Gendered body and self-consciousness', ['gender', 'emotional_vulnerability']),
 'T05': ('Repressed desire and sexual identity', ['sexuality']),
 'T06': ('Heteronormativity and internalised prejudice', ['sexuality', 'gender']),
 'T07': ('Male authority and patriarchal performance', ['gender']),
 'T08': ('Devotion and emotional dependency', ['gender', 'emotional_vulnerability']),
 'T09': ('People-pleasing and social conditioning', ['gender', 'emotional_vulnerability']),
 'T10': ('Maternal judgement, childhood shame and self-worth', ['emotional_vulnerability']),
 'T11': ('Sexual anxiety', ['sexuality', 'gender']),
 'T12': ('Desire, jealousy and triangulation', ['sexuality', 'emotional_vulnerability']),
 'T13': ('Truth, disclosure and betrayal', ['sexuality', 'emotional_vulnerability']),
 'T14': ('Self-assertion, spite and moral ambiguity', ['emotional_vulnerability']),
 'T15': ('Male vulnerability and insecurity', ['gender', 'emotional_vulnerability']),
 'T16': ('Hunger, hospitality and unequal labour', ['class', 'gender']),
}

# ----------------------------------------------------------------------------------------------
# HUMAN-GENERATED themes: the researcher's own key words / phrases, copied from her document.
# 'maps_to' links each phrase to a canonical theme; the mapping is a transparent analytical
# decision made for comparison only (see research/methodology.md).
# ----------------------------------------------------------------------------------------------
HUMAN = {
 1: {'title': 'Social class, alienation and appearances', 'keywords': [
     ('Social inequality', 'T01'), ('Class consciousness', 'T01'), ('Economic insecurity', 'T01'),
     ('Social status', 'T01'), ('Material privilege', 'T01'), ('Loneliness and alienation', 'T02'),
     ('Workplace relationships', 'T03'), ('Gender expectations', 'T04'),
     ('Insecurity and self-consciousness', 'T04'), ('Superficial social interactions', 'T03')]},
 2: {'title': 'Sexuality, desire and identity', 'keywords': [
     ('Sexual identity', 'T05'), ('Repressed desire', 'T05'), ('Same-sex relationships', 'T05'),
     ('Heteronormativity', 'T06'), ('Internalised prejudice', 'T06'), ('Jealousy and attraction', 'T12'),
     ('Loneliness', 'T02'), ('Sexual anxiety', 'T11'), ('Emotional confusion', 'T05'), ('Social conditioning', 'T09')]},
 3: {'title': 'Gender roles, power and emotional vulnerability', 'keywords': [
     ('Gender stereotypes', 'T07'), ('Male dominance', 'T07'), ('Emotional dependency', 'T08'),
     ('Patriarchal relationships', 'T07'), ('Power imbalance', 'T07'), ('People-pleasing behaviour', 'T09'),
     ('Childhood trauma', 'T10'), ('Self-worth', 'T10'), ('Social conformity', 'T09'), ('Unfulfilled desire', 'T05')]},
 4: {'title': 'Truth, betrayal and self-assertion', 'keywords': [
     ('Emotional manipulation', 'T14'), ('Jealousy and insecurity', 'T12'), ('Hidden relationships', 'T13'),
     ('Truth and disclosure', 'T13'), ('Betrayal', 'T13'), ('Sexual identity', 'T05'), ('Moral conflict', 'T14'),
     ('Power of speech', 'T14'), ('Emotional confrontation', 'T13'), ('Consequences of honesty', 'T13')]},
}

# ----------------------------------------------------------------------------------------------
# HUMAN full-text interpretation: the researcher's own interpretation (results/human_interpretation.json,
# extracted from her document by extract_human_interpretation.py). For comparison, each block's interpretation
# is coded to the canonical themes it discusses; every code carries an excerpt that must occur word for word in
# that block's human interpretation (checked below). The coding is an analytical choice, open to review.
# ----------------------------------------------------------------------------------------------
HUMAN_FULL_TEXT_CODING = {
 1: [('T01', "compares her own rented life with Tanu and Mahesh's expensive house and lifestyle"),
     ('T02', 'she feels like an outsider'),
     ('T04', 'she immediately thinks about her body')],
 2: [('T05', 'internal conflict between curiosity, attraction, social expectations and self-denial'),
     ('T06', 'socially conditioned to understand desire primarily through heterosexuality'),
     ('T12', "she watches Rani's attraction toward Mahesh"),
     ('T11', 'her own lack of sexual experience'),
     ('T02', 'connected to loneliness')],
 3: [('T07', 'he also controls who does what'),
     ('T08', "Tanu's happiness is connected to his approval and affection"),
     ('T09', 'connected to childhood conditioning and her fear of being judged as inadequate'),
     ('T10', 'her mother privately described her as a'),
     ('T16', 'the narrator is immediately assigned work in the kitchen')],
 4: [('T07', 'Mahesh tells her that she must stay'),
     ('T09', 'She automatically agrees.'),
     ('T10', "connects her behaviour with her mother's childhood accusation"),
     ('T12', 'the narrator interprets his behaviour as another rejection'),
     ('T11', 'her virginity'),
     ('T05', 'sexual frustration'),
     ('T13', "She exposes Tanu's previous relationship with Projapoti"),
     ('T14', 'she uses it as a weapon'),
     ('T15', "She recognizes Mahesh's vulnerability")],
}
HUMAN_INTERP_FILE = os.path.join(ROOT, 'results', 'human_interpretation.json')

def human_block_text(hi, bid):
    parts = []
    for it in hi['blocks'][str(bid)]['items']:
        parts += it['items'] if 'items' in it else [it['text']]
    return ' '.join(parts)

def E(pid, quote, kind='explicit'):
    return {'paragraph_id': pid, 'quote': quote, 'evidence_type': kind}

def TH(tid, subs, explanation, evidence, interpretation, overlaps=()):
    label, dims = THEMES[tid]
    return {'theme_id': tid, 'theme': label, 'dimensions': dims, 'subthemes': list(subs),
            'explanation': explanation, 'overlaps_with': list(overlaps), 'evidence': evidence,
            'interpretation': interpretation}

# ----------------------------------------------------------------------------------------------
# AI-GENERATED extraction (Claude, full-text reading, rules of prompts/prompt.txt)
# ----------------------------------------------------------------------------------------------
ANNOTATIONS = {
 1: {
  'major_themes': [
   TH('T01', ['housing', 'salary parity', 'servility to service workers'],
      'The narrator measures herself against the hosts by salary and housing and shows how little room she has to risk offending the dhaba boys.',
      [E('B1P2', 'you live in the hinterlands by yourself because that’s all you can afford on your salary'),
       E('B1P4', 'how many people your age and with practically the same goddamned salary get to disappear behind a door such as this every evening'),
       E('B1P2', 'You cannot risk angering the one source of good food in your neighborhood')],
      'Class is felt as envy of a peer rather than resentment of a distant elite: the salary is "practically the same", so the difference lies in marriage and property, which links class to gender.',
      ['Hunger, hospitality and unequal labour']),
   TH('T02', ['former colleagues', 'ambivalent friendship', 'bodily anxiety'],
      'The narrator doubts the friendship, attends out of obligation and registers physical tension at the door.',
      [E('B1P1', 'she isn’t really a friend friend'),
       E('B1P6', 'You quit these people a few months ago in pursuit of a flashier salary but now you have to spend an entire evening with them'),
       E('B1P5', 'your throat feels like it’s closing in', 'inferential')],
      'Her exit from the company for money is itself an alienation: she gained salary and lost belonging, and the party forces her back into a group she has partly left.',
      ['Class consciousness and economic insecurity']),
   TH('T03', ['duty', 'ironic self-presentation', 'office ties'],
      'Goodness is announced as a reason for attending, and she performs urgency at the doorbell.',
      [E('B1P1', 'because you are a good person'),
       E('B1P6', 'As if you are here to take care of serious business'),
       E('B1P5', 'We are done preening for you, sucker', 'inferential')],
      'The italicised-style intrusion ("sucker") reads as the narrator imagining the hosts\' display; whether it is her projection or their attitude is left open.',
      ['Alienation and social exclusion']),
   TH('T04', ['breasts and flatness', 'accepting compliments', 'surveillance of her own body'],
      'Her reaction to Mahesh\'s glance and compliment shows an internalised habit of checking her body against an unspoken standard.',
      [E('B1P9', 'maybe if you weren’t so flat-chested things would be different'),
       E('B1P9', 'you surreptitiously glance down to check that the buttons haven’t come undone'),
       E('B1P11', 'you haven’t mastered the art of accepting compliments in stride')],
      'Judith Butler\'s idea of gender as a repeated, regulated performance is useful here: the narrator polices her own body before anyone else does.',
      ['Gendered body and self-consciousness']),
   TH('T07', ['possessive gesture', 'protective violence', 'age gap'],
      'Mahesh is introduced through a possessive grip and a vow of violence on Tanu\'s behalf.',
      [E('B1P7', 'his arm possessively gripped around her tiny waist'),
       E('B1P8', 'what he would like to do to every man who has ever hurt Tanu'),
       E('B1P8', 'more like a creepy uncle', 'inferential')],
      'Protection and possession are fused from the opening; the narrator initially reads this as passion she envies, an ambivalence that returns in Block 4.',
      ['Desire, jealousy and triangulation']),
   TH('T12', ['envy of being desired', 'gaze'],
      'The narrator wonders what it feels like to be the object of Mahesh\'s passion.',
      [E('B1P8', 'you had wondered what it must feel like to be the object of such passion')],
      'Longing is directed at being desired, not at a person, so desire and gendered self-worth are entangled.',
      ['Male authority and patriarchal performance']),
  ],
  'gender_representation': [
   {'observation': 'Women\'s bodies are evaluated and self-policed; men\'s bodies (Mahesh\'s shaved head, Auro\'s legs) are described as comic or relaxed.',
    'evidence': [E('B1P9', 'maybe if you weren’t so flat-chested things would be different'), E('B1P7', 'his shaved head hovering like an egg over her bony shoulder')]}],
  'sexuality_and_identity': [
   {'observation': 'Same-sex romance is visible and unremarkable in the office circle (Pia and Projapoti) but the narrator\'s own desire is not yet shown in this block.',
    'evidence': [E('B1P13', 'Their romance is as new as it is tumultuous')]}],
  'social_class': [
   {'observation': 'The home\'s material display (door, furniture, location near Hauz Khas market) signals comfort the narrator reads as class distance.',
    'evidence': [E('B1P12', 'all stainless steel and white leather with tasteful accents of bamboo'), E('B1P4', 'you can tell this is expensive', 'inferential')]}],
  'emotional_vulnerability': [
   {'observation': 'Envy, self-consciousness and nervousness accompany her arrival.',
    'evidence': [E('B1P5', 'your throat feels like it’s closing in', 'inferential')]}],
  'character_relationships': [
   {'characters': ['Narrator', 'Tanu'], 'relation': 'former colleague; relationship described as not quite friendship',
    'evidence': [E('B1P1', 'she isn’t really a friend friend')]},
   {'characters': ['Narrator', 'Auro'], 'relation': 'she trained him as her replacement; he behaves as the senior',
    'evidence': [E('B1P15', 'He was hired to replace you')]},
   {'characters': ['Narrator', 'Projapoti'], 'relation': 'mentor-like warmth at work',
    'evidence': [E('B1P13', 'who took you under her wing when you first joined the company')]}],
  'conflicts': [
   {'type': 'internal', 'description': 'Obligation versus resentment about attending.', 'evidence': [E('B1P1', 'you could blow it off')]},
   {'type': 'social', 'description': 'Salary equality versus unequal property and marriage.', 'evidence': [E('B1P4', 'practically the same goddamned salary')]}],
  'symbolism': [
   {'symbol': 'the heavy black door', 'meaning': 'threshold of class and belonging', 'evidence': [E('B1P4', 'you can tell this is expensive', 'inferential')], 'evidence_type': 'inferential'},
   {'symbol': 'closing flower petals', 'meaning': 'bodily closing-up under social pressure', 'evidence': [E('B1P5', 'like flowers whose petals clam up at night', 'inferential')], 'evidence_type': 'inferential'}],
  'narrative_perspective': 'Second-person, present tense; "you" is both the narrator and an address that makes the reader share her discomfort. The sardonic voice mixes self-mockery and judgement.',
  'character_development': 'Introduction of the narrator\'s values (duty, envy, self-monitoring); no change yet.',
  'ambiguities': ['Whether the narrator\'s envy is mainly class-based or erotic (she envies both a house and being desired).',
                  'The "sucker" intrusion could be projection or the hosts\' actual attitude.'],
 },
 2: {
  'major_themes': [
   TH('T07', ['intellectual performance', 'male authority', 'centring of men\'s talk'],
      'Mahesh is staged as a guru; the narrator names the men\'s talk as something she is too tired to care about.',
      [E('B2P15', 'giving him the appearance of an enlightened guru dispensing wisdom to his disciples'),
       E('B2P4', 'too tired to care what any of the men—Nietzsche, Mahesh, or Auro—have thought or said'.replace('—', '—')),
       E('B2P14', 'Auro’s face is pinched with effort')],
      'Mahesh\'s authority is effortless and relational: it depends on an audience of devoted women, while the younger man must strain.',
      ['Devotion and emotional dependency']),
   TH('T08', ['devotee', 'adoration', 'two women watching one man'],
      'Tanu and Rani are described through devotion and admiration directed at Mahesh.',
      [E('B2P2', 'her eyes filled more with the ardor of a devotee than the love of a wife'),
       E('B2P3', 'the way one does while admiring a work of art'),
       E('B2P15', 'his adoring wife')],
      'Marriage is figured as worship; the language of religious devotion naturalises an unequal emotional economy.',
      ['Male authority and patriarchal performance']),
   TH('T16', ['absent food', 'broken fridge', 'hospitality as display'],
      'The hosts offer little to eat or drink while displaying expensive things; the narrator\'s hunger is ignored.',
      [E('B2P4', 'hoping someone will offer you a drink or a bite to eat'),
       E('B2P5', 'Two shelves lined with bottles of expensive liquor, a handful of glasses, and two bowls of chips'),
       E('B2P7', 'What kind of human beings invite people over with a broken fridge and no ice?')],
      'The gap between display (liquor, design) and care (food, ice) turns hospitality into a measure of status and whose needs count.',
      ['Class consciousness and economic insecurity']),
   TH('T01', ['corporate sociability', 'status display'],
      'The narrator compares this party with her new company\'s parties and judges her social skills inadequate.',
      [E('B2P8', 'Truth be told, you’re bad at it'),
       E('B2P8', 'you stick to the few faces you know like an infant latched to a warm teat')],
      'Her career move to a "flashier" employer demands social labour for which she feels unequipped, pairing class mobility with insecurity.',
      ['Alienation and social exclusion']),
   TH('T05', ['denial', 'fantasy', 'concealed desire'],
      'She imagines Tanu and Projapoti together, then immediately labels it meaningless and disowns the identity.',
      [E('B2P13', 'It was a harmless pastime, really'),
       E('B2P13', 'It certainly didn’t mean you were a lesbian'),
       E('B2P13', 'It’s good you nipped them in the bud')],
      'The repeated denials work as evidence of the thing denied; the narrator\'s sexuality is never declared, so this remains a reading, not a stated fact.',
      ['Heteronormativity and internalised prejudice']),
   TH('T06', ['"if you were a man"', 'discomfort', 'compulsory heterosexuality'],
      'Desire for a woman is only imaginable to her as a man\'s desire; lesbian affection prompts disgust.',
      [E('B2P13', 'If you were a man, you would have had no trouble liking Tanu’s curly hair'),
       E('B2P13', 'But you aren’t a man, and therefore these thoughts are silly and pointless'),
       E('B2P12', 'You have watched enough lesbian PDA to last you a lifetime'),
       E('B2P12', 'your stomach churns', 'inferential')],
      'Queer theory\'s notion of heteronormativity explains how she maps desire onto a gender binary, with "lesbian PDA" experienced as an intrusion.',
      ['Repressed desire and sexual identity']),
   TH('T12', ['watching', 'Tanu\'s insecurity', 'Rani\'s display'],
      'The narrator notices Rani watching Mahesh and Tanu watching Rani, a chain of looks.',
      [E('B2P16', 'the deliberate swing in her hips, an invitation if ever there was one'),
       E('B2P17', 'You aren’t the only one watching Rani watch Mahesh'),
       E('B2P17', 'her eyes keep flitting back to Rani')],
      'The narrator is both observer and participant in a triangle of looks; Tanu\'s anxiety plants the jealousy that explodes in Block 4.',
      ['Devotion and emotional dependency']),
   TH('T09', ['suppressed question', 'politeness'],
      'She swallows her question about the "appetizers" and pretends to agree.',
      [E('B2P11', 'You consider asking the question but then kill it in your throat'),
       E('B2P11', 'But really, what do you know?')],
      'Self-silencing is established here and is what the climactic speech in Block 4 breaks.',
      ['Power of speech (Block 4)']),
  ],
  'gender_representation': [
   {'observation': 'Men talk and are listened to (Nietzsche, video games); women watch, refill chips and pass bowls.',
    'evidence': [E('B2P17', 'Tanu has quietly refilled the bowls of chips and is passing them around'), E('B2P15', 'enlightened guru dispensing wisdom to his disciples')]}],
  'sexuality_and_identity': [
   {'observation': 'The narrator denies and disowns her erotic imagining of two women.',
    'evidence': [E('B2P13', 'It certainly didn’t mean you were a lesbian')]}],
  'social_class': [
   {'observation': 'Expensive liquor but no ice or substantial food.',
    'evidence': [E('B2P5', 'Two shelves lined with bottles of expensive liquor, a handful of glasses, and two bowls of chips')]}],
  'emotional_vulnerability': [
   {'observation': 'Hunger and tiredness amplify her sense of being overlooked.',
    'evidence': [E('B2P4', 'as if you didn’t just arrive at a party, hungry and tired from a long day at work')]}],
  'character_relationships': [
   {'characters': ['Tanu', 'Mahesh'], 'relation': 'wife as devotee; husband as authority',
    'evidence': [E('B2P2', 'her eyes filled more with the ardor of a devotee than the love of a wife')]},
   {'characters': ['Tanu', 'Projapoti'], 'relation': 'former couple, now friends',
    'evidence': [E('B2P12', 'it was in fact Tanu and Projapoti who used to be an item')]},
   {'characters': ['Pia', 'Projapoti'], 'relation': 'current couple whose affection unsettles the narrator',
    'evidence': [E('B2P12', 'She plants mini kisses on Projapoti’s neck and your stomach churns')]},
   {'characters': ['Rani', 'Mahesh'], 'relation': 'Rani watches Mahesh admiringly; Tanu notices',
    'evidence': [E('B2P17', 'You aren’t the only one watching Rani watch Mahesh')]}],
  'conflicts': [
   {'type': 'internal', 'description': 'Desire for Tanu versus self-denial.', 'evidence': [E('B2P13', 'these thoughts are silly and pointless')]},
   {'type': 'interpersonal', 'description': 'Hunger versus unattentive hosts.', 'evidence': [E('B2P4', 'no one moves a muscle')]}],
  'symbolism': [
   {'symbol': 'ice and the broken fridge', 'meaning': 'withheld comfort; the hosts\' display without care', 'evidence': [E('B2P6', 'Our fridge broke this morning. So, no ice.')], 'evidence_type': 'inferential'},
   {'symbol': 'the abyss', 'meaning': 'Auro\'s "ability to turn away" may echo the narrator\'s turning away from desire', 'evidence': [E('B2P1', 'it is our ability to turn away from the abyss that makes us human', 'inferential')], 'evidence_type': 'inferential'},
   {'symbol': 'potato chips as "appetizers"', 'meaning': 'scarcity disguised as style', 'evidence': [E('B2P10', 'Mahesh suggested we keep the appetizers light')], 'evidence_type': 'inferential'}],
  'narrative_perspective': 'Second person continues. Ironic asides ("Poor you!") expose the narrator\'s defensiveness; her view of lesbians as unfamiliar is part of her unreliability about herself.',
  'character_development': 'The narrator\'s repressed desire and habit of silence are established.',
  'ambiguities': ['Whether the narrator\'s disgust at PDA is homophobia, envy, or discomfort with intimacy.',
                  'Whether Auro\'s "turn away from the abyss" is meant as parallel to the narrator or as Auro\'s own self-justification.'],
 },
 3: {
  'major_themes': [
   TH('T09', ['obligation', 'help as duty', 'self-mockery'],
      'She offers help before thinking and calls herself a fool for always being the only helper.',
      [E('B3P4', 'you are too well brought up to not offer help'),
       E('B3P5', 'you ask before you can stop yourself'),
       E('B3P6', 'you are the only fool who has offered to help')],
      'Upbringing produces reflexive service, which the narrator both performs and mocks.',
      ['Hunger, hospitality and unequal labour', 'Maternal judgement, childhood shame and self-worth']),
   TH('T07', ['control of space', 'control of time', 'monologue as authority'],
      'Mahesh gives orders, shields Tanu from labour and holds the narrator in the kitchen with talk.',
      [E('B3P7', 'Not you, my sweets. Not tonight. Tonight, you get full release from the kitchen.'),
       E('B3P11', 'you emerge from the kitchen two hours later'),
       E('B3P11', 'It was him listening to himself spread wisdom')],
      'Benevolence and control coexist: Tanu is released from labour by his decision, and the guest is pressed into it.',
      ['Hunger, hospitality and unequal labour']),
   TH('T16', ['guest labour', 'hunger', 'time'],
      'The narrator does the host\'s work, hungry, in a hot kitchen, for two hours.',
      [E('B3P6', 'In a hot kitchen in April in New Delhi. And on an empty stomach.'),
       E('B3P6', 'The other guests are absorbed in each other or their phones'),
       E('B3P11', 'you emerge from the kitchen two hours later')],
      'The labour reversal (a guest cooks while the hosts and others idle) makes hospitality an unequal exchange.',
      ['People-pleasing and social conditioning']),
   TH('T10', ['"ugly stepchild"', 'mother\'s contempt', 'pride turned to shame'],
      'A childhood memory pairs a peer\'s praise with the mother\'s overheard judgement.',
      [E('B3P9', 'You did the right thing. You loved the ugly stepchild.'),
       E('B3P9', 'hearing those words had swelled your heart with pride'),
       E('B3P10', 'I cannot believe I gave birth to a spineless child.')],
      'Affect theory\'s attention to how shame is transmitted helps read the sandwich: pride in kindness is converted into a lasting sense of being "spineless".',
      ['People-pleasing and social conditioning']),
   TH('T11', ['virginity', 'film-derived fear', 'comparison with others'],
      'She believes she alone is a virgin and ties her avoidance to a childhood fear learnt from Hindi films.',
      [E('B3P13', 'You are most definitely the only one in this room still a virgin'),
       E('B3P13', 'paralyzed by your childhood fear of getting pregnant the first time you sleep with someone, the way it always happens in Hindi films'),
       E('B3P13', 'you have never been charming')],
      'Popular cinema is named as an agent of social conditioning; the claim "the only one" is the narrator\'s unverified assumption.',
      ['Maternal judgement, childhood shame and self-worth', 'People-pleasing and social conditioning']),
   TH('T06', ['heterosexual template', 'predictability'],
      'The narrator explains Tanu and Projapoti\'s relationship by the model of a husband and wife.',
      [E('B3P14', 'They agreed easily, like a husband and wife married for decades'),
       E('B3P14', 'back then you knew even less about lesbians than you know now'),
       E('B3P14', 'Their relationship lacked the ravenous passion that Projapoti’s relationship with Pia oozed from the start')],
      'Lesbian relationships are understood through marital norms and a "passion" scale, evidence of internalised heteronormative categories.',
      ['Repressed desire and sexual identity']),
   TH('T05', ['avoidance', 'voyeuristic attention', 'distance from queer sociality'],
      'She avoids the couple\'s housewarming yet notices Pia\'s body "like a dare".',
      [E('B3P2', 'Why put yourself through additional discomfort anyway?'),
       E('B3P2', 'her tight ass pointed to the sky like a dare')],
      'Avoidance and attention are held together without being named as desire, preserving ambiguity.',
      ['Desire, jealousy and triangulation']),
   TH('T08', ['affection as gift', 'uncertainty'],
      'Tanu receives Mahesh\'s attention like a gift she does not know how to hold.',
      [E('B3P8', 'as if she doesn’t know what to do with this wealth of affection', 'inferential')],
      'The narrator reads Tanu\'s sweetness as vulnerable dependence rather than equal exchange.',
      ['Male authority and patriarchal performance']),
   TH('T12', ['desire for Auro', 'wish for attention'],
      'She imagines touching Auro and wants him to notice her.',
      [E('B3P12', 'If you stretch your legs, your toes will brush against Auro’s thigh'),
       E('B3P12', 'you want to say something smart so he will take notice')],
      'Desire is tentative and mediated by alcohol and the wish to be noticed.',
      ['Sexual anxiety']),
  ],
  'gender_representation': [
   {'observation': 'Mahesh decides who is excused from labour; he calls Tanu "my sweets" and she is "released" from the kitchen.',
    'evidence': [E('B3P7', 'Not you, my sweets. Not tonight.')]},
   {'observation': 'The narrator\'s fear of pregnancy comes from a gendered cinematic script.',
    'evidence': [E('B3P13', 'the way it always happens in Hindi films')]}],
  'sexuality_and_identity': [
   {'observation': 'Lesbian relationships are interpreted via marital and passion scripts.',
    'evidence': [E('B3P14', 'They agreed easily, like a husband and wife married for decades')]}],
  'social_class': [
   {'observation': 'Guest labour substitutes for hospitality in a home that displays comfort.',
    'evidence': [E('B3P6', 'In a hot kitchen in April in New Delhi. And on an empty stomach.')]}],
  'emotional_vulnerability': [
   {'observation': 'Shame and contempt from the mother frame the narrator\'s self-worth.',
    'evidence': [E('B3P10', 'I cannot believe I gave birth to a spineless child.')]}],
  'character_relationships': [
   {'characters': ['Narrator', 'Mother'], 'relation': 'a mother\'s overheard contempt for her daughter',
    'evidence': [E('B3P10', 'I cannot believe I gave birth to a spineless child.')]},
   {'characters': ['Mahesh', 'Narrator'], 'relation': 'host directs guest\'s labour and talk',
    'evidence': [E('B3P11', 'It was him listening to himself spread wisdom')]},
   {'characters': ['Pia', 'Projapoti'], 'relation': 'volatile couple who nonetheless move in together',
    'evidence': [E('B3P2', 'two weeks later, Pia and Projapoti had opted to move in together')]}],
  'conflicts': [
   {'type': 'internal', 'description': 'Fear of sex versus wish to be noticed.', 'evidence': [E('B3P13', 'paralyzed by your childhood fear')]},
   {'type': 'interpersonal', 'description': 'Narrator\'s labour versus Mahesh\'s monologues.', 'evidence': [E('B3P11', 'It was never a discussion')]}],
  'symbolism': [
   {'symbol': 'the dismembered cucumber sandwich', 'meaning': 'the narrator\'s sense of herself as the discarded, "spineless" one', 'evidence': [E('B3P9', 'That poor sandwich hadn’t kept its shape')], 'evidence_type': 'inferential'},
   {'symbol': 'the onions', 'meaning': 'servile labour and tears held back', 'evidence': [E('B3P9', 'Mahesh hands you three enormous onions')], 'evidence_type': 'inferential'}],
  'narrative_perspective': 'Second person with an embedded analepsis (the Christmas party; the mother\'s remark) that supplies motive for the narrator\'s later actions.',
  'character_development': 'The block supplies backstory: conditioning (upbringing, cinema) explains her silence and avoidance.',
  'ambiguities': ['Whether the sandwich story shows kindness or a failure of self-protection (the story gives both the peer\'s praise and the mother\'s judgement).',
                  'Whether Mahesh\'s kitchen "invitation" is exploitation or clumsy generosity.'],
 },
 4: {
  'major_themes': [
   TH('T13', ['disclosure', 'hidden relationship', 'silence turned into speech'],
      'The narrator\'s question exposes Tanu\'s hidden past with Projapoti.',
      [E('B4P23', 'does it feel weird watching Projapoti with another woman?'),
       E('B4P24', 'He has never known about Tanu’s relationship with Projapoti'),
       E('B4P25', 'She refuses to look at Mahesh even though he is right there')],
      'The speech act does what the earlier blocks held back; whether it is truth-telling or betrayal depends on motive, which the text itself questions.',
      ['Self-assertion, spite and moral ambiguity', 'Heteronormativity and internalised prejudice']),
   TH('T14', ['spite', 'self-justification', 'reclaiming "spinelessness"'],
      'She acts against her own warning, then blames alcohol and circumstances.',
      [E('B4P22', 'You are done being that nine-year-old kid who got the dismembered sandwich'),
       E('B4P23', 'you ignore the warning inside your head'),
       E('B4P21', 'Or at least that’s how you justify your words for days afterward')],
      'The act is self-assertion against her mother\'s verdict and cruelty toward Tanu in one gesture; the narrator\'s own phrase "justify" signals doubt.',
      ['Maternal judgement, childhood shame and self-worth']),
   TH('T06', ['"satisfied by a woman"', 'prudishness', 'male anxiety'],
      'Mahesh is characterised as unable to bear that his wife could have been satisfied by a woman.',
      [E('B4P24', 'Mahesh is the kind of man who cannot swallow the idea of his wife ever having been satisfied by a woman'),
       E('B4P18', 'He has no use for your prudishness')],
      'Heteronormativity is shown at the level of masculine pride; the claim is the narrator\'s inference ("you have always guessed"), not stated by Mahesh.',
      ['Male authority and patriarchal performance']),
   TH('T07', ['protective violence', 'reproductive framing', 'public intimacy'],
      'Mahesh\'s protectiveness takes the form of lists of men to beat up and claims to Tanu\'s body.',
      [E('B4P25', 'his head full of the names of men he wants to beat up to protect his wife'),
       E('B4P16', 'I’m drinking less to boost my bad boys'),
       E('B4P18', 'kisses her wetly on her mouth')],
      'The text contrasts Mahesh\'s mild change in drinking with Tanu\'s prescription and abstinence, without asserting inequality outright.',
      ['Male vulnerability and insecurity']),
   TH('T15', ['fear of loss', 'softening', 'narrator\'s empathy'],
      'The narrator briefly sees Mahesh as frightened and soft.',
      [E('B4P21', 'you are looking at a vulnerable man, a man frightened that he might lose what he loves most in his life'),
       E('B4P20', 'he is no longer a man with an egg-shaped head, obsessed with the sound of his own voice')],
      'Her recognition of his fear is immediately followed by the act that uses it, a moral conflict the text leaves unresolved.',
      ['Self-assertion, spite and moral ambiguity']),
   TH('T08', ['seeking reassurance', 'trembling voice'],
      'Tanu turns to Mahesh\'s attractiveness and to the narrator for corroboration.',
      [E('B4P19', 'I don’t think you recognize your own attractiveness, Mahesh'),
       E('B4P19', 'Tanu’s voice trembles and she looks at you for corroboration')],
      'Tanu\'s insecurity about Rani shows dependence on reassurance and prefigures the question that unsettles her.',
      ['Desire, jealousy and triangulation']),
   TH('T11', ['opportunity', 'fear', 'regret'],
      'Auro\'s question is both desired and feared; she later wishes she had accepted.',
      [E('B4P3', 'What are you doing afterwards?'),
       E('B4P4', 'fearful and desperate at the same time, itching to grasp the opportunity, but also horrified at where it might lead you'),
       E('B4P22', 'a part of you wishes you had gone ahead with it, just this once')],
      'Ambivalence rather than refusal characterises her sexual anxiety.',
      ['Desire, jealousy and triangulation']),
   TH('T12', ['rejection', 'Rani as rival', 'displacement'],
      'Auro\'s offer passes to Rani, which the narrator names among her reasons for lashing out.',
      [E('B4P21', 'how he offered it to Rani'),
       E('B4P9', 'He offers Rani a lift and she takes it'),
       E('B4P22', 'the meaningless fuck you would have been for Auro')],
      'Jealousy circulates: Tanu fears Rani, the narrator resents Rani, and each is displaced onto the other.',
      ['Self-assertion, spite and moral ambiguity']),
   TH('T09', ['compliance', 'politeness', 'swallowed anger'],
      'She obeys Mahesh\'s order to stay and eats food she dislikes.',
      [E('B4P5', 'Surely, you aren’t thinking of leaving?'),
       E('B4P6', 'the words tumble out of you automatically, even as an angry, bitter taste fills your mouth'),
       E('B4P7', 'not wanting to seem rude or inconsiderate, you load up a plate')],
      'Compliance is the last step before the rupture: the narrator\'s anger is physical ("bitter taste") before it is verbal.',
      ['Male authority and patriarchal performance']),
   TH('T10', ['"No, Ma"', 'delayed answer to the mother'],
      'The mother\'s verdict is answered inwardly ("I was not spineless") and then acted against.',
      [E('B4P6', 'No, Ma, I was not spineless.'),
       E('B4P22', 'You are done disappointing your mother with your spinelessness')],
      'The sandwich memory returns as motive; the narrator\'s identity is formed in opposition to the mother\'s words.',
      ['Self-assertion, spite and moral ambiguity']),
   TH('T02', ['pity', 'departures', 'empty streets'],
      'Auro\'s look is pity and the vendors have gone, leaving the narrator alone with the hosts.',
      [E('B4P9', 'they are filled with pity, the kind one might reserve for a wretched dog'),
       E('B4P23', 'the empty streets below where the vendors have long since packed their stores and left for the night')],
      'The emptied street externalises her isolation; Auro\'s pity reinforces her low status.',
      ['Hunger, hospitality and unequal labour']),
   TH('T16', ['failed meal', 'lost appetite', 'waste'],
      'The long-awaited dinner is inedible and others waste it.',
      [E('B4P7', 'The overcooked rice does no favors to the undercooked meat'),
       E('B4P7', 'You have lost your appetite'),
       E('B4P8', 'They waste most of what they ladled on their plate and leave without bothering to wait for others to finish')],
      'The promised "specialty" fails; hospitality is shown as performance without substance, matching Mahesh\'s talk.',
      ['Superficial sociability and performed goodness']),
  ],
  'gender_representation': [
   {'observation': 'Tanu bears the medical burden of conception while Mahesh jokes about his "bad boys".',
    'evidence': [E('B4P11', 'My OBGYN has prescribed hormone pills'), E('B4P16', 'I’m drinking less to boost my bad boys')]},
   {'observation': 'Mahesh\'s masculinity includes violent protectiveness and fragility.',
    'evidence': [E('B4P25', 'his head full of the names of men he wants to beat up to protect his wife'), E('B4P21', 'a man frightened that he might lose what he loves most in his life')]}],
  'sexuality_and_identity': [
   {'observation': 'Tanu\'s relationship with Projapoti is hidden from her husband.',
    'evidence': [E('B4P24', 'He has never known about Tanu’s relationship with Projapoti')]}],
  'social_class': [
   {'observation': 'The narrator\'s hunger, the failed meal and the vendors\' absence close the story\'s material imagery.',
    'evidence': [E('B4P7', 'You have lost your appetite')]}],
  'emotional_vulnerability': [
   {'observation': 'Vulnerability is distributed: Mahesh\'s fear, Tanu\'s trembling, the narrator\'s ambivalence.',
    'evidence': [E('B4P19', 'Tanu’s voice trembles and she looks at you for corroboration')]}],
  'character_relationships': [
   {'characters': ['Narrator', 'Tanu'], 'relation': 'the question breaks the friendship\'s surface; ending leaves it unresolved',
    'evidence': [E('B4P25', 'Tanu holds your gaze until you cannot bear it anymore and have to look away')]},
   {'characters': ['Tanu', 'Mahesh'], 'relation': 'devotion and concealment',
    'evidence': [E('B4P25', 'She refuses to look at Mahesh even though he is right there')]},
   {'characters': ['Narrator', 'Auro'], 'relation': 'offer, hesitation, pity',
    'evidence': [E('B4P9', 'they are filled with pity')]}],
  'conflicts': [
   {'type': 'internal', 'description': 'Desire for connection versus fear; spinelessness versus assertion.', 'evidence': [E('B4P22', 'You are done disappointing your mother with your spinelessness')]},
   {'type': 'interpersonal', 'description': 'The narrator\'s question versus Tanu\'s secret.', 'evidence': [E('B4P23', 'does it feel weird watching Projapoti with another woman?')]},
   {'type': 'social', 'description': 'Heteronormative marriage versus a past lesbian relationship.', 'evidence': [E('B4P24', 'cannot swallow the idea of his wife ever having been satisfied by a woman')]}],
  'symbolism': [
   {'symbol': 'Tanu\'s orange juice and Pia\'s vodka', 'meaning': 'her abstinence broken at the end; an act that can be read as defiance, grief or relapse', 'evidence': [E('B4P26', 'she picks up Pia’s half-empty glass of vodka and takes a sip')], 'evidence_type': 'inferential'},
   {'symbol': 'empty streets', 'meaning': 'isolation and absence of witnesses', 'evidence': [E('B4P23', 'the empty streets below where the vendors have long since packed their stores and left for the night')], 'evidence_type': 'inferential'}],
  'narrative_perspective': 'Second person; the narrator explains her own act with a list of excuses and says she will "realize again and again what you have done", which makes her self-assessment explicitly retrospective and self-doubting.',
  'character_development': 'The narrator moves from silence and compliance to speech; the outcome (guilt, assertion, cruelty) is deliberately open.',
  'ambiguities': ['Whether the narrator\'s question is truth-telling, betrayal, or revenge.',
                  'Whether Tanu\'s final sip is rebellion, hurt, or regression (the text does not say).',
                  'The narrator\'s claim that Mahesh could not accept a woman satisfying his wife is her inference.'],
 },
}

WHOLE_STORY = {
 'central_tensions': [
  'Politeness and silence versus a violent act of speech.',
  'Display (hospitality, intellect, marriage) versus substance (food, care, honesty).',
  'Protective masculinity versus possessive masculinity.',
  'Repressed desire versus the heteronormative categories the narrator uses to describe it.'],
 'ambiguities': [
  'The narrator\'s sexuality is never declared; the text shows denial, fantasy and ambivalence only.',
  'The motives for the final question are given only as the narrator\'s retrospective excuses.'],
}

# ----------------------------------------------------------------------------------------------
# Validation
# ----------------------------------------------------------------------------------------------
def norm(s):
    s = s.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
    return re.sub(r'\s+', ' ', s).strip().lower()

def load_paragraphs():
    paras, cur = {}, None
    n = 0
    for line in open(CORPUS, encoding='utf-8'):
        line = line.rstrip('\n')
        m = re.match(r'\[\[BLOCK (\d)\]\]', line)
        if m:
            cur, n = int(m.group(1)), 0
        elif cur and line.strip():
            n += 1
            # apply the same cleaning as preprocess.py (abbreviations, spaced punctuation)
            t = re.sub(r'[\u00a0\u2009\u200a\u202f\u2002\u2003]', ' ', line)
            for k, v in {'T V': 'TV', 'P D A': 'PDA', 'O B G Y N': 'OBGYN', 'T M I': 'TMI'}.items():
                t = t.replace(k, v)
            t = re.sub(r'\s+([!?.,;:])', r'\1', t)
            paras[f'B{cur}P{n}'] = norm(t)
    return paras

def validate(data, paras):
    errors, quotes = [], 0
    ALLOWED_TYPES = {'explicit', 'inferential'}
    DIMS = {'gender', 'sexuality', 'class', 'emotional_vulnerability'}
    for key in ('story', 'author', 'metadata', 'human_generated', 'blocks', 'whole_story'):
        if key not in data: errors.append(f'missing key: {key}')
    if len(data.get('blocks', [])) != 4: errors.append('expected exactly 4 blocks')

    def check_ev(ev, where):
        nonlocal quotes
        if ev.get('evidence_type') not in ALLOWED_TYPES: errors.append(f'{where}: bad evidence_type')
        pid, q = ev.get('paragraph_id'), ev.get('quote', '')
        if pid not in paras: errors.append(f'{where}: unknown paragraph {pid}'); return
        if len(q.split()) > 25: errors.append(f'{where}: quote > 25 words ({pid})')
        if norm(q) not in paras[pid]: errors.append(f'{where}: quote NOT FOUND in {pid}: {q[:60]!r}')
        quotes += 1

    for b in data.get('blocks', []):
        bid = b.get('block_id')
        for t in b.get('major_themes', []):
            where = f'block {bid} theme {t.get("theme_id")}'
            if not t.get('explanation'): errors.append(f'{where}: missing explanation')
            if not t.get('evidence'): errors.append(f'{where}: no evidence')
            if not set(t.get('dimensions', [])) <= DIMS: errors.append(f'{where}: bad dimension')
            for ev in t.get('evidence', []): check_ev(ev, where)
        for sec in ('gender_representation', 'sexuality_and_identity', 'social_class', 'emotional_vulnerability',
                    'character_relationships', 'conflicts', 'symbolism'):
            for item in b.get(sec, []):
                for ev in item.get('evidence', []): check_ev(ev, f'block {bid} {sec}')
        for must in ('narrative_perspective', 'character_development', 'ambiguities'):
            if not b.get(must): errors.append(f'block {bid}: missing {must}')
    return errors, quotes

def build():
    paras = load_paragraphs()
    hi = json.load(open(HUMAN_INTERP_FILE, encoding='utf-8'))
    blocks = []
    for bid in (1, 2, 3, 4):
        a = ANNOTATIONS[bid]
        htext = human_block_text(hi, bid)
        for tid, ex in HUMAN_FULL_TEXT_CODING[bid]:
            assert tid in THEMES and ex in htext, f'human full-text coding: excerpt not found in Block {bid}: {ex!r}'
        blocks.append({'block_id': bid, 'human_generated_themes': {'title': HUMAN[bid]['title'],
                          'keywords': [{'phrase': p, 'maps_to': m} for p, m in HUMAN[bid]['keywords']]},
                       'human_full_text_themes': [{'theme_id': t, 'excerpt': ex} for t, ex in HUMAN_FULL_TEXT_CODING[bid]],
                       **a})
    return {
     'story': 'The Party', 'author': 'Sayantani Dasgupta',
     'metadata': {
        'corpus_file': 'corpus/The_Party.txt', 'prompt_file': 'prompts/prompt.txt',
        'ai_extraction_source': 'Claude (claude-sonnet-5-5); full-text reading under prompts/prompt.txt. All quotations machine-verified against the corpus.',
        'human_full_text_interpretation': 'results/human_interpretation.json',
        'human_full_text_coding_note': 'blocks[].human_full_text_themes codes the researcher\'s full-text interpretation to canonical themes; each code carries a verified excerpt from her text.',
        'theme_vocabulary': {k: {'label': v[0], 'dimensions': v[1]} for k, v in THEMES.items()},
        'human_to_canonical_mapping_note': 'The mapping of the researcher\'s key phrases to canonical themes was made for comparison only.',
     },
     'human_generated': {str(b): HUMAN[b]['title'] for b in HUMAN},
     'blocks': blocks, 'whole_story': WHOLE_STORY}

def run_local_llm(model, host='http://localhost:11434'):
    """Optional: send prompt + corpus to a local Ollama model and return parsed JSON (not run in the original build)."""
    story = open(CORPUS, encoding='utf-8').read()
    prompt = open(PROMPT, encoding='utf-8').read().replace('<<STORY_TEXT>>', story)
    req = urllib.request.Request(host + '/api/generate', method='POST',
        data=json.dumps({'model': model, 'prompt': prompt, 'stream': False, 'format': 'json', 'options': {'temperature': 0}}).encode(),
        headers={'Content-Type': 'application/json'})
    raw = json.loads(urllib.request.urlopen(req, timeout=3600).read())['response']
    return json.loads(raw)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', choices=['annotated', 'local-llm'], default='annotated')
    ap.add_argument('--model', default='llama3.1:8b')
    args = ap.parse_args()
    paras = load_paragraphs()
    if args.source == 'local-llm':
        data = run_local_llm(args.model)
        out = OUT.replace('theme_extraction.json', 'theme_extraction_llm.json')
    else:
        data, out = build(), OUT
    errs, nq = validate(data, paras)
    if errs:
        print('VALIDATION FAILED:'); [print(' -', e) for e in errs]; sys.exit(1)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump(data, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'OK: {out}  ({nq} quotations verified against the corpus)')
