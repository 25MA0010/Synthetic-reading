#!/usr/bin/env python3
"""
visualization.py -- Step 6: computational analysis and visualisation.
Synthetic Reading: The Party by Sayantani Dasgupta

Reads ONLY results/theme_extraction.json (the validated extraction) and writes
  figures/generated_visualisations/fig1..fig5 (PNG, 300 dpi)
  results/figure_data.json (every plotted number, for the HTML page and for checking)

Counting rules (also printed in each figure's caption on the website):
* "Evidence item" = one verified quotation attached to a major theme of one block.
* A zero means: the extraction cited no evidence for that theme in that block. Every block WAS annotated,
  so a zero is a finding of this extraction, not missing data.
* Human full-text interpretation: the researcher's interpretation coded to canonical themes per block
  (blocks[].human_full_text_themes); drawn as dots in Fig. 4.
* Frequencies of words are NOT used as evidence of themes anywhere in this script.

Run from repo root:  python visualization/visualization.py     (needs pandas matplotlib seaborn networkx)
"""
import itertools, json, os, collections
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import networkx as nx
import numpy as np
import pandas as pd
import seaborn as sns

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
DATA = os.path.join(ROOT, 'results', 'theme_extraction.json')
FIG = os.path.join(ROOT, 'figures', 'generated_visualisations')
os.makedirs(FIG, exist_ok=True)

data = json.load(open(DATA, encoding='utf-8'))
vocab = {k: v['label'] for k, v in data['metadata']['theme_vocabulary'].items()}
vocab_dims = {k: v['dimensions'] for k, v in data['metadata']['theme_vocabulary'].items()}
TIDS = sorted(vocab)
SHORT = {  # compact labels for figures
 'T01': 'Class & economic insecurity', 'T02': 'Alienation & exclusion', 'T03': 'Superficial sociability',
 'T04': 'Gendered body & self-consciousness', 'T05': 'Repressed desire & identity', 'T06': 'Heteronormativity & internalised prejudice',
 'T07': 'Male authority & patriarchy', 'T08': 'Devotion & dependency', 'T09': 'People-pleasing & conditioning',
 'T10': 'Maternal judgement & self-worth', 'T11': 'Sexual anxiety', 'T12': 'Desire, jealousy, triangulation',
 'T13': 'Truth, disclosure, betrayal', 'T14': 'Self-assertion, spite, ambiguity', 'T15': 'Male vulnerability',
 'T16': 'Hunger, hospitality, labour'}
BLOCK_NAMES = {1: 'Block 1', 2: 'Block 2', 3: 'Block 3', 4: 'Block 4'}
DIMS = ['gender', 'sexuality', 'class', 'emotional_vulnerability']
DIM_LABEL = {'gender': 'Gender', 'sexuality': 'Sexuality', 'class': 'Class', 'emotional_vulnerability': 'Emotional vulnerability'}
DIM_COL = {'gender': '#7a4e9e', 'sexuality': '#c0504d', 'class': '#d19a2a', 'emotional_vulnerability': '#2f7f93'}
NAVY = '#1f2a44'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'axes.edgecolor': '#555', 'axes.titleweight': 'bold',
                     'figure.dpi': 110, 'savefig.dpi': 300, 'font.size': 10})

# ---------------- tidy tables built from the JSON ----------------
ev_rows, theme_rows = [], []
for b in data['blocks']:
    for t in b['major_themes']:
        theme_rows.append({'block': b['block_id'], 'tid': t['theme_id'], 'n_evidence': len(t['evidence']),
                           'n_sub': len(t['subthemes'])})
        for e in t['evidence']:
            ev_rows.append({'block': b['block_id'], 'tid': t['theme_id'], 'pid': e['paragraph_id'], 'type': e['evidence_type']})
EV = pd.DataFrame(ev_rows); TR = pd.DataFrame(theme_rows)
fig_data = {}

# ================= FIGURE 1: theme x block heatmap =================
M = (EV.groupby(['tid', 'block']).size().unstack(fill_value=0)
       .reindex(index=TIDS, columns=[1, 2, 3, 4], fill_value=0))
fig, ax = plt.subplots(figsize=(8.6, 7.2))
sns.heatmap(M, annot=True, fmt='d', cmap=sns.light_palette('#2f5d8a', as_cmap=True), cbar_kws={'label': 'Verified evidence items'},
            linewidths=.6, linecolor='white', ax=ax, vmin=0)
ax.set_yticklabels([SHORT[t] for t in TIDS], rotation=0)
ax.set_xticklabels([BLOCK_NAMES[b] for b in M.columns], rotation=0)
ax.set_xlabel(''); ax.set_ylabel('')
ax.set_title('Fig. 1  Distribution of themes across the four blocks', loc='left', color=NAVY)
fig.text(0.01, 0.005, 'Cell = number of verified quotations the AI extraction cites for that theme in that block; 0 = none cited (all blocks were annotated).',
         fontsize=7.5, color='#444')
fig.tight_layout(rect=(0, 0.02, 1, 1)); fig.savefig(os.path.join(FIG, 'fig1_theme_distribution_blocks.png')); plt.close(fig)
fig_data['fig1'] = {SHORT[t]: {str(b): int(M.loc[t, b]) for b in M.columns} for t in TIDS}
fig_data['fig1_block_totals'] = {str(b): int(M[b].sum()) for b in M.columns}
fig_data['fig1_themes_per_block'] = {str(b): int((M[b] > 0).sum()) for b in M.columns}

# ================= FIGURE 2: theme & subtheme frequency =================
tot = EV.groupby(['tid', 'type']).size().unstack(fill_value=0).reindex(TIDS, fill_value=0)
for c in ('explicit', 'inferential'):
    if c not in tot: tot[c] = 0
tot['all'] = tot['explicit'] + tot['inferential']
order = tot.sort_values('all').index.tolist()
subs = TR.groupby('tid')['n_sub'].sum().reindex(TIDS, fill_value=0)
fig, (a1, a2) = plt.subplots(1, 2, figsize=(12.5, 6.6), gridspec_kw={'width_ratios': [1.35, 1]}, sharey=True)
y = np.arange(len(order))
a1.barh(y, tot.loc[order, 'explicit'], color='#2f5d8a', label='explicit evidence')
a1.barh(y, tot.loc[order, 'inferential'], left=tot.loc[order, 'explicit'], color='#d19a2a', label='interpretive inference')
a1.set_yticks(y); a1.set_yticklabels([SHORT[t] for t in order]); a1.set_xlabel('Verified evidence items (all blocks)')
a1.set_title('A  Major themes by evidence type', loc='left', color=NAVY); a1.legend(frameon=False, loc='lower right')
a2.barh(y, subs.loc[order], color='#6b8f71'); a2.set_xlabel('Distinct subtheme labels recorded (all blocks)')
a2.set_title('B  Subthemes recorded per theme', loc='left', color=NAVY)
for a in (a1, a2):
    a.spines[['top', 'right']].set_visible(False)
fig.suptitle('Fig. 2  Major theme and subtheme frequency in the extracted dataset', x=0.01, ha='left', fontweight='bold', color=NAVY)
fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(os.path.join(FIG, 'fig2_theme_subtheme_frequency.png')); plt.close(fig)
fig_data['fig2'] = {SHORT[t]: {'explicit': int(tot.loc[t, 'explicit']), 'inferential': int(tot.loc[t, 'inferential']),
                                'subthemes': int(subs.loc[t])} for t in TIDS}
fig_data['fig2_type_totals'] = {'explicit': int(tot['explicit'].sum()), 'inferential': int(tot['inferential'].sum())}

# ================= FIGURE 3: co-occurrence network =================
# Method: two themes are linked when they cite the SAME paragraph (shared textual evidence), across the whole story.
par_themes = collections.defaultdict(set)
for _, r in EV.iterrows(): par_themes[r['pid']].add(r['tid'])
W = collections.Counter()
for pid, ts in par_themes.items():
    for a, b in itertools.combinations(sorted(ts), 2): W[(a, b)] += 1
G = nx.Graph()
size = EV.groupby('tid').size()
for t in TIDS: G.add_node(t, n=int(size.get(t, 0)))
for (a, b), w in W.items(): G.add_edge(a, b, weight=w)
fig, ax = plt.subplots(figsize=(12, 9))
ordered = sorted(TIDS, key=lambda t: (DIMS.index(vocab_dims[t][0]), t))   # group nodes by first-listed dimension
pos = {t: (np.cos(2 * np.pi * i / len(ordered)), np.sin(2 * np.pi * i / len(ordered))) for i, t in enumerate(ordered)}
node_col = [DIM_COL[vocab_dims[t][0]] for t in G.nodes]
nx.draw_networkx_edges(G, pos, ax=ax, width=[0.8 + 1.7 * G[u][v]['weight'] for u, v in G.edges], edge_color='#8f99ab', alpha=.75)
nx.draw_networkx_nodes(G, pos, ax=ax, node_size=[160 + 70 * G.nodes[t]['n'] for t in G.nodes], node_color=node_col,
                       edgecolors='white', linewidths=1.5)
for t, (x, y) in pos.items():
    ax.text(x * 1.2, y * 1.2, SHORT[t] + ('' if G.degree(t) else ' (no shared paragraph)'), fontsize=8.5, color=NAVY,
            ha='left' if x > 0.05 else ('right' if x < -0.05 else 'center'), va='center')
ax.set_xlim(-1.9, 1.9); ax.set_ylim(-1.45, 1.45)
ax.axis('off')
ax.legend(handles=[Patch(color=DIM_COL[d], label=f'first-listed dimension: {DIM_LABEL[d]}') for d in DIMS], loc='lower left', frameon=False, fontsize=8)
ax.set_title('Fig. 3  Theme co-occurrence network (shared textual evidence)', loc='left', color=NAVY)
fig.text(0.01, 0.01, 'Edge = two themes cite the same paragraph; edge width = number of shared paragraphs; node size = evidence items. '
         'Co-occurrence shows where readings overlap, not causation.', fontsize=7.5, color='#444')
fig.tight_layout(rect=(0, 0.02, 1, 1)); fig.savefig(os.path.join(FIG, 'fig3_theme_cooccurrence_network.png')); plt.close(fig)
top_edges = sorted(W.items(), key=lambda kv: -kv[1])
fig_data['fig3'] = {'n_nodes': G.number_of_nodes(), 'n_edges': G.number_of_edges(),
                    'edges': [{'a': SHORT[a], 'b': SHORT[b], 'shared_paragraphs': w} for (a, b), w in top_edges],
                    'degree': {SHORT[t]: int(d) for t, d in G.degree()},
                    'shared_paragraph_ids': {f'{a}-{b}': sorted(p for p, ts in par_themes.items() if a in ts and b in ts) for (a, b) in W}}

# ================= FIGURE 4: human vs AI =================
# Human (preliminary) = researcher's key phrases mapped to canonical themes, per block.
# Human (full text)   = researcher's full-text interpretation coded to canonical themes, per block (blocks[].human_full_text_themes).
# AI                  = theme has >=1 verified evidence item in the block.
H = pd.DataFrame(0, index=TIDS, columns=[1, 2, 3, 4]); HF = H.copy()
for b in data['blocks']:
    for k in b['human_generated_themes']['keywords']: H.loc[k['maps_to'], b['block_id']] = 1
    for k in b['human_full_text_themes']: HF.loc[k['theme_id'], b['block_id']] = 1
A = (M > 0).astype(int)
def states(Hm):
    return {(t, b): (3 if Hm.loc[t, b] and A.loc[t, b] else (1 if Hm.loc[t, b] else (2 if A.loc[t, b] else 0))) for t in TIDS for b in (1, 2, 3, 4)}
state, state_ft = states(H), states(HF)
fig = plt.figure(figsize=(13.5, 7.8)); gs = fig.add_gridspec(1, 2, width_ratios=[1.25, 1], wspace=0.22)
ax = fig.add_subplot(gs[0]); ax.set_xlim(0, 4); ax.set_ylim(len(TIDS), 0)
cols = {0: '#f1f1f1', 1: '#9db8d8', 2: '#e4b363', 3: '#4c8f6b'}
for i, t in enumerate(TIDS):
    for j, b in enumerate((1, 2, 3, 4)):
        ax.add_patch(plt.Rectangle((j, i), 0.96, 0.9, color=cols[state[(t, b)]]))
        if HF.loc[t, b]:
            ax.plot(j + 0.48, i + 0.45, marker='o', ms=7, mfc='#1f2a44', mec='white', mew=1.2)
ax.set_yticks([i + .45 for i in range(len(TIDS))]); ax.set_yticklabels([SHORT[t] for t in TIDS])
ax.set_xticks([j + .48 for j in range(4)]); ax.set_xticklabels(['Block 1', 'Block 2', 'Block 3', 'Block 4'], fontsize=9)
ax.xaxis.tick_top(); ax.tick_params(length=0)
for s_ in ax.spines.values(): s_.set_visible(False)
from matplotlib.lines import Line2D
ax.legend(handles=[Patch(color=cols[3], label='Preliminary key words + AI'), Patch(color=cols[1], label='Preliminary key words only'),
                   Patch(color=cols[2], label='AI only'), Patch(color=cols[0], label='Neither'),
                   Line2D([], [], marker='o', ls='', ms=7, mfc='#1f2a44', mec='white', label='Discussed in human full-text interpretation')],
          loc='upper center', bbox_to_anchor=(0.5, -0.01), ncol=2, frameon=False, fontsize=8)
ax.set_title('A  Theme presence by block and source', loc='left', color=NAVY, pad=28)
ax2 = fig.add_subplot(gs[1])
cnt = {b: collections.Counter(state[(t, b)] for t in TIDS) for b in (1, 2, 3, 4)}
cnt_ft = {b: collections.Counter(state_ft[(t, b)] for t in TIDS) for b in (1, 2, 3, 4)}
for off, C_, tag in ((-0.2, cnt, 'K'), (0.2, cnt_ft, 'F')):
    bottom = np.zeros(4)
    for k, lab in ((3, 'Both'), (1, 'Human only'), (2, 'AI only')):
        v = np.array([C_[b][k] for b in (1, 2, 3, 4)])
        ax2.bar(np.arange(4) + off, v, width=0.36, bottom=bottom, color=cols[k], label=lab if tag == 'K' else None, edgecolor='white', lw=0.6)
        for x, (vv, bb) in enumerate(zip(v, bottom)):
            if vv: ax2.text(x + off, bb + vv / 2, str(vv), ha='center', va='center', fontsize=8.5, color='white' if k == 3 else '#222')
        bottom += v
    for x in range(4):
        ax2.text(x + off, bottom[x] + 0.25, tag, ha='center', va='bottom', fontsize=8.5, fontweight='bold', color=NAVY)
ax2.set_xticks(range(4)); ax2.set_xticklabels(['Block 1', 'Block 2', 'Block 3', 'Block 4']); ax2.set_ylabel('Number of canonical themes')
ax2.spines[['top', 'right']].set_visible(False); ax2.legend(frameon=False, fontsize=8, loc='upper left')
ax2.set_title('B  Agreement with the AI per block', loc='left', color=NAVY)
ax2.set_xlabel('K = preliminary key words   F = full-text interpretation', fontsize=9)
fig.suptitle('Fig. 4  Human readings (preliminary key words and full-text interpretation) versus AI-generated extraction', x=0.01, ha='left', fontweight='bold', color=NAVY)
fig.text(0.01, 0.005, 'Preliminary = researcher\'s key phrases mapped to the 16 canonical themes; full text = researcher\'s interpretation coded to the same themes (excerpts in the JSON). '
         'AI = >=1 verified quotation.', fontsize=7.5, color='#444')
fig.subplots_adjust(top=0.84, bottom=0.12, left=0.25, right=0.98)
fig.savefig(os.path.join(FIG, 'fig4_human_vs_ai_themes.png')); plt.close(fig)
cells = lambda st, k: [{'theme': SHORT[t], 'block': b} for t in TIDS for b in (1, 2, 3, 4) if st[(t, b)] == k]
fig_data['fig4'] = {'per_block': {str(b): {'both': cnt[b][3], 'human_only': cnt[b][1], 'ai_only': cnt[b][2], 'neither': cnt[b][0]} for b in (1, 2, 3, 4)},
                    'human_only_cells': cells(state, 1), 'ai_only_cells': cells(state, 2),
                    'full_text_per_block': {str(b): {'both': cnt_ft[b][3], 'human_only': cnt_ft[b][1], 'ai_only': cnt_ft[b][2], 'neither': cnt_ft[b][0]} for b in (1, 2, 3, 4)},
                    'full_text_human_only_cells': cells(state_ft, 1), 'full_text_ai_only_cells': cells(state_ft, 2),
                    'full_text_themes_not_in_keywords': sorted({SHORT[t] for t in TIDS for b in (1, 2, 3, 4) if HF.loc[t, b] and not H.loc[t].any()})}

# ================= FIGURE 5: intersections of the four dimensions =================
ev_per_theme = EV.groupby('tid').size().reindex(TIDS, fill_value=0)
X = pd.DataFrame(0, index=DIMS, columns=DIMS)
for t in TIDS:
    ds = vocab_dims[t]
    for d in ds: X.loc[d, d] += ev_per_theme[t]
    for d1, d2 in itertools.permutations(ds, 2): X.loc[d1, d2] += ev_per_theme[t]
D = pd.DataFrame(0, index=DIMS, columns=[1, 2, 3, 4])
for _, r in EV.iterrows():
    for d in vocab_dims[r['tid']]: D.loc[d, r['block']] += 1
fig, (a1, a2) = plt.subplots(1, 2, figsize=(12.5, 5.6), gridspec_kw={'width_ratios': [1, 1.1]})
sns.heatmap(X, annot=True, fmt='d', cmap=sns.light_palette('#6b3f8a', as_cmap=True), linewidths=.8, linecolor='white', ax=a1,
            cbar_kws={'label': 'Evidence items'})
a1.set_xticklabels([DIM_LABEL[d] for d in DIMS], rotation=25, ha='right'); a1.set_yticklabels([DIM_LABEL[d] for d in DIMS], rotation=0)
a1.set_title('A  Evidence items shared by two dimensions\n(diagonal = all items for that dimension)', loc='left', color=NAVY, fontsize=10)
bottom = np.zeros(4)
for d in DIMS:
    v = D.loc[d].values; a2.bar(range(4), v, bottom=bottom * 0, color=DIM_COL[d], width=0.19, label=DIM_LABEL[d]) if False else None
w = 0.2
for i, d in enumerate(DIMS):
    a2.bar(np.arange(4) + (i - 1.5) * w, D.loc[d].values, width=w, color=DIM_COL[d], label=DIM_LABEL[d])
a2.set_xticks(range(4)); a2.set_xticklabels(['Block 1', 'Block 2', 'Block 3', 'Block 4']); a2.set_ylabel('Evidence items tagged')
a2.spines[['top', 'right']].set_visible(False); a2.legend(frameon=False, fontsize=8)
a2.set_title('B  Dimensions tagged by evidence, per block', loc='left', color=NAVY, fontsize=10)
fig.suptitle('Fig. 5  Gender, sexuality, class and emotional vulnerability', x=0.01, ha='left', fontweight='bold', color=NAVY)
fig.text(0.01, 0.005, 'Each theme carries fixed dimension tags (gender / sexuality / class / emotional vulnerability); an evidence item counts toward every dimension its theme carries.',
         fontsize=7.5, color='#444')
fig.tight_layout(rect=(0, 0.03, 1, 0.94)); fig.savefig(os.path.join(FIG, 'fig5_dimension_intersections.png')); plt.close(fig)
fig_data['fig5'] = {'matrix': {DIM_LABEL[r]: {DIM_LABEL[c]: int(X.loc[r, c]) for c in DIMS} for r in DIMS},
                    'per_block': {DIM_LABEL[d]: {str(b): int(D.loc[d, b]) for b in (1, 2, 3, 4)} for d in DIMS}}
fig_data['totals'] = {'evidence_items': int(len(EV)), 'themes_recorded': int(len(TR)),
                      'paragraphs_cited': int(EV['pid'].nunique())}
json.dump(fig_data, open(os.path.join(ROOT, 'results', 'figure_data.json'), 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
print('figures written to', FIG); print(json.dumps(fig_data['totals']))
