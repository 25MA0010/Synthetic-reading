#!/usr/bin/env python3
"""build_site.py -- assembles index.html from the repository's own data files, so every number, quotation and the
prompt shown on the website come from results/*.json, prompts/prompt.txt and the scripts. Run after
preprocess.py, extract_highlights.py, make_partial_reading.py, Theme_JSON.py, visualization.py and appetite_check.py:
    python visualization/build_site.py
"""
import html, json, os, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')) if '__file__' in globals() else '.'
rd = lambda *p: open(os.path.join(ROOT, *p), encoding='utf-8').read()
E = html.escape
T = json.loads(rd('results', 'theme_extraction.json'))
F = json.loads(rd('results', 'figure_data.json'))
S = json.loads(rd('results', 'corpus_summary.json'))
SEL = json.loads(rd('partial_reading', 'selected_passages.json'))
OBS = json.loads(rd('partial_reading', 'partial_observations.json'))
PROMPT = rd('prompts', 'prompt.txt')
PRE = rd('preprocessing', 'preprocess.py')
VOCAB = T['metadata']['theme_vocabulary']
HI = json.loads(rd('results', 'human_interpretation.json'))
RAW = {1: 1060, 2: 1114, 3: 1101, 4: 1072}      # whitespace word counts measured on the uploaded file (Block 1 excludes title/byline)
STATED = {1: 1064, 2: 1114, 3: 1101, 4: 1072}

def func_src(name):
    m = re.search(r'(def %s\(.*?)(?=\n\S)' % name, PRE, re.S)
    return m.group(1).rstrip() if m else ''

def tbl(headers, rows, cls=''):
    h = ''.join(f'<th>{E(x)}</th>' for x in headers)
    b = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f'<div class="tablewrap"><table class="{cls}"><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table></div>'

# ---------- Step 1 tables ----------
wc_rows = [[f'Block {b}', f'{STATED[b]:,}', f'{RAW[b]:,}', f"{S[str(b)]['words_whitespace']:,}", S[str(b)]['paragraphs'], S[str(b)]['sentences']] for b in (1, 2, 3, 4)]
wc_rows.append(['Total', f'{sum(STATED.values()):,}', f'{sum(RAW.values()):,}', f"{S['total']['words_whitespace']:,}", S['total']['paragraphs'], S['total']['sentences']])
wc_table = tbl(['Block', 'Stated in document', 'Counted (raw upload)', 'Counted (clean corpus)', 'Paragraphs', 'Sentences'], wc_rows)
pr_rows = []
for b in '1234':
    for i, p in enumerate(SEL['sample'][b]):
        pr_rows.append([f'Block {b}' if i == 0 else '', f'<span class="pid">{p["paragraph_id"]}</span> {E(p["text"])}',
                        E(OBS[b]['observations']) if i == 0 else '', E('; '.join(OBS[b]['themes'])) if i == 0 else ''])
pr_table = tbl(['Block', 'Highlighted passage (exact text)', 'Initial observations (from the highlighted passages only)', 'Preliminary themes'], pr_rows, 'passages')
PST = SEL['stats']
cov_rows = [[f'Block {b}', ', '.join(p['paragraph_id'] for p in SEL['sample'][b]), f"{PST[b]['paragraphs_selected']} of {PST[b]['paragraphs_in_block']}",
             f"{PST[b]['words_selected']:,} of {PST[b]['words_in_block']:,}", f"{PST[b]['share_of_words']:.0%}"] for b in '1234']
cov_rows.append(['Total', '', f"{sum(PST[b]['paragraphs_selected'] for b in '1234')} of {sum(PST[b]['paragraphs_in_block'] for b in '1234')}",
                 f"{PST['total']['words_selected']:,} of {PST['total']['words_in_block']:,}", f"{PST['total']['share_of_words']:.0%}"])
cov_table = tbl(['Block', 'Highlighted paragraphs', 'Paragraphs', 'Words (clean corpus)', 'Share of block'], cov_rows)
kw_rows = [[f'Block {b}', f"{len(OBS[b]['keywords_visible'])} of {len(OBS[b]['keywords_visible']) + len(OBS[b]['keywords_later'])}",
            E('; '.join(OBS[b]['keywords_visible'])), E('; '.join(OBS[b]['keywords_later']))] for b in '1234']
kw_table = tbl(['Block', 'Visible in the partial reading', "Researcher's key words already visible in the highlighted passages", 'Key words that come only from the rest of the block'], kw_rows)
human_rows = []
for b in T['blocks']:
    human_rows.append([f'Block {b["block_id"]}: {E(b["human_generated_themes"]["title"])}',
                       '; '.join(E(k['phrase']) for k in b['human_generated_themes']['keywords'])])
human_table = tbl(['Researcher\'s block (human, preliminary)', 'Key words / phrases (unchanged from the document)'], human_rows)

audit = tbl(['Step', 'Existing progress', 'Problems identified', 'Required improvements', 'Final status'], [
 ['1 Partial reading', 'Story divided into four blocks with word counts stated; passages read for the partial reading highlighted in yellow.', 'Highlighted passages not yet recorded as data; no written first impressions. Block 1 count (1,064) includes the 4 words of title and byline; the story itself is 1,060.', 'Highlights extracted from the document by script, mapped to paragraph IDs and checked against the corpus; observations written from the highlighted passages only.', 'Completed.'],
 ['2 Methodology and reflexivity', 'Research question and key words per block.', 'No research problem, objectives, framework, positionality or ethics.', 'Written in research/methodology.md and on this page.', 'Completed.'],
 ['3 Upload and preprocessing', 'Complete story present in four blocks.', 'Typographic artefacts (spaced abbreviations such as "T V", "P D A", hair-space characters); no script.', 'Clean corpus with block markers; preprocess.py with paragraph IDs.', 'Completed.'],
 ['4 Prompt engineering', 'None.', 'Missing.', 'prompt.txt with evidence rules and JSON schema.', 'Completed.'],
 ['5 Extraction and JSON', 'Key words per block and a full-text "Human Interpretation" section.', 'No structured data; human interpretation not linked to themes or evidence.', 'Validated JSON with 93 verified theme quotations; human key words and full-text interpretation stored separately and coded to the same canonical themes.', 'Completed.'],
 ['6 Visualisation', 'None.', 'Missing.', 'Five figures computed from the JSON.', 'Completed.'],
 ['7 Interpretation', 'Human interpretation of each block and of the whole story.', 'No theoretical framing; no comparison with the AI reading; no conclusions answering the research question.', 'Theory-led interpretation tied to figures and verified quotations; human–AI comparison; conclusions answering the research question.', 'Completed.'],
])

# ---------- Step 5 (per block) ----------
def ev_html(evs):
    return ''.join(f'<li><span class="pid">{e["paragraph_id"]}</span> &ldquo;{E(e["quote"])}&rdquo; <span class="tag {e["evidence_type"]}">{e["evidence_type"]}</span></li>' for e in evs)
panes = []
for b in T['blocks']:
    items = ''
    for t in b['major_themes']:
        dims = ' '.join(f'<span class="dim d-{d}">{E(d.replace("_", " "))}</span>' for d in t['dimensions'])
        items += (f'<article class="theme"><h4>{E(t["theme"])} <small>{t["theme_id"]}</small></h4><p>{dims}</p>'
                  f'<p><strong>Why:</strong> {E(t["explanation"])}</p><ul class="ev">{ev_html(t["evidence"])}</ul>'
                  f'<p><strong>Interpretation:</strong> {E(t["interpretation"])}</p>'
                  f'<p class="small"><strong>Subthemes:</strong> {E("; ".join(t["subthemes"]))}</p></article>')
    extra = (f'<div class="card"><h4>Narrative perspective</h4><p>{E(b["narrative_perspective"])}</p><h4>Character development</h4><p>{E(b["character_development"])}</p>'
             f'<h4>Ambiguities preserved</h4><ul>{"".join("<li>" + E(a) + "</li>" for a in b["ambiguities"])}</ul>'
             f'<h4>Character relationships</h4><ul>{"".join("<li><strong>" + E(" – ".join(r["characters"])) + ":</strong> " + E(r["relation"]) + "</li>" for r in b["character_relationships"])}</ul>'
             f'<h4>Symbolism (inferential)</h4><ul>{"".join("<li><strong>" + E(s["symbol"]) + ":</strong> " + E(s["meaning"]) + "</li>" for s in b["symbolism"])}</ul></div>')
    panes.append(f'<div class="pane" id="blk{b["block_id"]}" role="tabpanel"><p class="note">Human title: <em>{E(b["human_generated_themes"]["title"])}</em> &nbsp;|&nbsp; AI themes with evidence: <strong>{len(b["major_themes"])}</strong></p>{items}{extra}</div>')
def hitems(items):
    out = ''
    for it in items:
        k = it['kind']
        if k == 'labelled': out += f'<p><strong>{E(it["label"])}:</strong> {E(it["text"])}</p>'
        elif k == 'list': out += '<ul>' + ''.join(f'<li>{E(x)}</li>' for x in it['items']) + '</ul>'
        elif k == 'lines': out += '<ul class="arrows">' + ''.join(f'<li>{E(x)}</li>' for x in it['items']) + '</ul>'
        elif k == 'heading': out += f'<h4>{E(it["text"])}</h4>'
        else: out += f'<p>{E(it["text"])}</p>'
    return out
hpanes = []
for b in T['blocks']:
    hb = HI['blocks'][str(b['block_id'])]
    codes = ' '.join(f'<span class="badge">{E(VOCAB[c["theme_id"]]["label"])}</span>' for c in b['human_full_text_themes'])
    hpanes.append(f'<div class="pane hpane" id="hblk{b["block_id"]}" role="tabpanel"><article class="theme"><h4>Block {b["block_id"]}: {E(hb["title"])}</h4>{hitems(hb["items"])}<p class="small"><strong>Coded themes:</strong> {codes}</p></article></div>')
hpanes.append(f'<div class="pane hpane" id="hblk5" role="tabpanel"><article class="theme"><h4>Overall human interpretation</h4>{hitems(HI["overall"])}</article></div>')
htabs = ''.join(f'<button role="tab" class="tab htab{" on" if i == 1 else ""}" data-t="hblk{i}">{"Block " + str(i) if i < 5 else "Overall"}</button>' for i in (1, 2, 3, 4, 5))
tabs = ''.join(f'<button role="tab" class="tab{" on" if i == 1 else ""}" data-t="blk{i}">Block {i}</button>' for i in (1, 2, 3, 4))
sample_json = json.dumps({k: (T['blocks'][0]['major_themes'][0][k] if k != 'evidence' else T['blocks'][0]['major_themes'][0]['evidence'][:1]) for k in
                          ('theme_id', 'theme', 'dimensions', 'subthemes', 'explanation', 'overlaps_with', 'evidence', 'interpretation')}, ensure_ascii=False, indent=2)
struct = '{ "story", "author", "metadata", "human_generated", "blocks": [ { "block_id", "human_generated_themes", "major_themes": [ theme_id, theme, dimensions, subthemes, explanation, overlaps_with, evidence[ {paragraph_id, quote, evidence_type} ], interpretation ], "gender_representation", "sexuality_and_identity", "social_class", "emotional_vulnerability", "character_relationships", "conflicts", "symbolism", "narrative_perspective", "character_development", "ambiguities" } ], "whole_story" }'
vocab_rows = [[k, E(v['label']), E(', '.join(d.replace('_', ' ') for d in v['dimensions']))] for k, v in VOCAB.items()]
vocab_table = tbl(['ID', 'Canonical theme', 'Dimensions tagged'], vocab_rows)
f4 = F['fig4']
h_only = '; '.join(f'{c["theme"]} (Block {c["block"]})' for c in f4['human_only_cells'])

# ---------- Step 6 figure cards ----------
FIGS = [
 ('fig1_theme_distribution_blocks.png', 'Fig. 1. Distribution of themes across the four blocks',
  'Where in the story each theme is evidenced.', 'Count of verified quotations per theme per block (theme_extraction.json, major_themes[].evidence). Zero = no quotation cited; every block was annotated, so zero is not missing data.',
  'Evidence per block: ' + ', '.join(f'Block {k} = {v}' for k, v in F['fig1_block_totals'].items()) + '. Distinct themes with evidence: ' + ', '.join(f'{v}' for v in F['fig1_themes_per_block'].values()) + ' (Blocks 1–4). Truth/disclosure and self-assertion appear only in Block 4; class and economic insecurity only in Blocks 1–2.',
  'Counts depend on how many quotations the annotator chose to cite; they show where the extraction found support, not how important a theme is.'),
 ('fig2_theme_subtheme_frequency.png', 'Fig. 2. Major theme and subtheme frequency',
  'Which themes carry the most evidence, and how finely each was articulated.', 'Panel A: quotations per theme split by evidence type. Panel B: number of subtheme labels recorded per theme across blocks.',
  f'Male authority and patriarchal performance has most evidence ({F["fig2"]["Male authority & patriarchy"]["explicit"] + F["fig2"]["Male authority & patriarchy"]["inferential"]} items), then hunger/hospitality/labour, desire/jealousy and heteronormativity (9 each). Of {F["totals"]["evidence_items"]} quotations, {F["fig2_type_totals"]["explicit"]} are labelled explicit and {F["fig2_type_totals"]["inferential"]} inferential.',
  'Subtheme labels are mostly unique strings, so Panel B counts articulation, not repetition. "Explicit" describes the quotation; the theme it supports is still an interpretation.'),
 ('fig3_theme_cooccurrence_network.png', 'Fig. 3. Theme co-occurrence network',
  'Which themes are argued from the same passages.', 'Two themes are linked when they cite the same paragraph ID; edge width = number of shared paragraphs; node size = evidence items. Nodes are placed on a circle grouped by first-listed dimension (no force layout, so position carries no meaning).',
  f'{F["fig3"]["n_edges"]} of the possible theme pairs are linked. Strongest: ' + '; '.join(f'{e["a"]} – {e["b"]} ({e["shared_paragraphs"]})' for e in F['fig3']['edges'][:4]) + '. Class and economic insecurity and Gendered body share no paragraph with any other theme.',
  'A link means shared evidence, not a causal or conceptual relation. Short stories reuse the same paragraphs for several readings, so overlap is partly a property of the annotation.'),
 ('fig4_human_vs_ai_themes.png', 'Fig. 4. Human readings versus AI-generated extraction',
  'How the researcher\'s two readings (preliminary key words and full-text interpretation) and the AI extraction agree and differ.', 'The researcher\'s key phrases are mapped to 16 canonical themes (cell colour); her full-text interpretation is coded to the same themes per block, each code backed by an excerpt from her text (dot). AI presence = at least one verified quotation in that block. Panel B counts agreement for each human reading against the AI.',
  f'Key words vs AI: agreement in {sum(v["both"] for v in f4["per_block"].values())} of 64 cells, human-only {sum(v["human_only"] for v in f4["per_block"].values())} ({h_only}), AI-only {sum(v["ai_only"] for v in f4["per_block"].values())}. Full text vs AI: agreement in {sum(v["both"] for v in f4["full_text_per_block"].values())}, human-only {sum(v["human_only"] for v in f4["full_text_per_block"].values())}, AI-only {sum(v["ai_only"] for v in f4["full_text_per_block"].values())}. Male vulnerability and hunger/hospitality/labour are missing from the key words but present in the full-text interpretation (Blocks 4 and 3).',
  'The human readings are block-level texts, not quotation sets, so the comparison is coarse. Mapping key words and coding the full text to themes are analytical choices, documented in the JSON. The AI here is one model run once.'),
 ('fig5_dimension_intersections.png', 'Fig. 5. Gender, sexuality, class and emotional vulnerability',
  'How the four central dimensions share evidence.', 'Each theme carries fixed dimension tags; an evidence item counts toward every dimension its theme carries. Panel A: items shared by two dimensions (diagonal = all items). Panel B: items per dimension per block.',
  'Gender ' + str(F['fig5']['matrix']['Gender']['Gender']) + ', emotional vulnerability ' + str(F['fig5']['matrix']['Emotional vulnerability']['Emotional vulnerability']) + ', sexuality ' + str(F['fig5']['matrix']['Sexuality']['Sexuality']) + ', class ' + str(F['fig5']['matrix']['Class']['Class']) + ' items. Gender overlaps most with emotional vulnerability (' + str(F['fig5']['matrix']['Gender']['Emotional vulnerability']) + ') and sexuality (' + str(F['fig5']['matrix']['Gender']['Sexuality']) + '); class and sexuality share none (0).',
  'Tags are fixed at theme level, so the matrix reflects the coding scheme as well as the text; it does not prove intersectionality. It is a map for the interpretation in Step 7.'),
]
fig_cards = ''
for i, (fn, title, purpose, method, interp, lim) in enumerate(FIGS, 1):
    fig_cards += (f'<figure class="card fig" id="fig{i}"><img src="figures/generated_visualisations/{fn}" alt="{E(title)}" loading="lazy">'
                  f'<figcaption><strong>{E(title)}</strong></figcaption>'
                  f'<dl><dt>Analytical purpose</dt><dd>{E(purpose)}</dd><dt>Method of calculation</dt><dd>{E(method)}</dd>'
                  f'<dt>Data source</dt><dd><code>results/theme_extraction.json</code> via <code>visualization/visualization.py</code>; numbers in <code>results/figure_data.json</code></dd>'
                  f'<dt>Interpretation (descriptive)</dt><dd>{E(interp)}</dd><dt>Limitations</dt><dd>{E(lim)}</dd></dl></figure>')
chart_data = json.dumps({'labels': ['Block 1', 'Block 2', 'Block 3', 'Block 4'],
                         'dims': {k: [v[str(b)] for b in (1, 2, 3, 4)] for k, v in F['fig5']['per_block'].items()}})

REFS = [
 'Ahmed, S. (2004). <em>The cultural politics of emotion</em>. Edinburgh University Press.',
 'Bender, E. M., Gebru, T., McMillan-Major, A., &amp; Shmitchell, S. (2021). On the dangers of stochastic parrots: Can language models be too big? In <em>Proceedings of the 2021 ACM Conference on Fairness, Accountability, and Transparency</em> (pp. 610–623). ACM. https://doi.org/10.1145/3442188.3445922',
 'Bourdieu, P. (1984). <em>Distinction: A social critique of the judgement of taste</em> (R. Nice, Trans.). Harvard University Press.',
 'Bourdieu, P. (1986). The forms of capital. In J. G. Richardson (Ed.), <em>Handbook of theory and research for the sociology of education</em> (pp. 241–258). Greenwood Press.',
 'Braun, V., &amp; Clarke, V. (2006). Using thematic analysis in psychology. <em>Qualitative Research in Psychology, 3</em>(2), 77–101. https://doi.org/10.1191/1478088706qp063oa',
 'Butler, J. (1990). <em>Gender trouble: Feminism and the subversion of identity</em>. Routledge.',
 'Crenshaw, K. (1989). Demarginalizing the intersection of race and sex: A Black feminist critique of antidiscrimination doctrine, feminist theory and antiracist politics. <em>University of Chicago Legal Forum, 1989</em>(1), 139–167.',
 'Crenshaw, K. (1991). Mapping the margins: Intersectionality, identity politics, and violence against women of color. <em>Stanford Law Review, 43</em>(6), 1241–1299. https://doi.org/10.2307/1229039',
 'Moretti, F. (2013). <em>Distant reading</em>. Verso.',
 'Ramsay, S. (2011). <em>Reading machines: Toward an algorithmic criticism</em>. University of Illinois Press.',
 'Rich, A. (1980). Compulsory heterosexuality and lesbian existence. <em>Signs, 5</em>(4), 631–660.',
 'Sedgwick, E. K. (1990). <em>Epistemology of the closet</em>. University of California Press.',
 'Warner, M. (1991). Introduction: Fear of a queer planet. <em>Social Text</em>, (29), 3–17.',
]
refs = ''.join(f'<li>{r}</li>' for r in REFS)

# ---------- Step 7 · Interpretation ----------
# Every quotation used in Step 7 goes through Q(), which checks it is an exact substring of exactly one paragraph of the
# clean corpus and adds that paragraph's ID. A quotation that fails stops the build (same rule as Theme_JSON.py).
CORPUS = json.loads(rd('results', 'corpus_blocks.json'))
PARAS = [(p['paragraph_id'], p['text']) for blk in CORPUS.values() for p in blk]
APP = json.loads(rd('results', 'step7_appetite_check.json'))
STEP7_QUOTES = []

def Q(text):
    found = [pid for pid, t in PARAS if text in t]
    assert len(found) == 1, f'Step 7 quotation not found exactly once in corpus: {text!r} -> {found}'
    STEP7_QUOTES.append({'quote': text, 'paragraph_id': found[0]})
    return f'&ldquo;{E(text)}&rdquo;&nbsp;<span class="pid">{found[0]}</span>'

def _htext(key):
    items = HI['overall'] if key == 'overall' else HI['blocks'][key]['items']
    return ' '.join(' '.join(it['items']) if 'items' in it else it['text'] for it in items)
def HQ(block, text):
    """Quote from the researcher's full-text interpretation; must occur in that block's interpretation."""
    raw = html.unescape(text)
    assert raw in _htext(block), f'human interpretation excerpt not found in {block}: {raw!r}'
    return f'&ldquo;{E(raw)}&rdquo;'

def ev_count(tid):
    return sum(len(t['evidence']) for b in T['blocks'] for t in b['major_themes'] if t['theme_id'] == tid)

M = F['fig5']['matrix']
pb = F['fig4']['per_block']
pf = F['fig4']['full_text_per_block']; N_BOTH_FT = sum(v['both'] for v in pf.values()); N_HO_FT = sum(v['human_only'] for v in pf.values()); N_AO_FT = sum(v['ai_only'] for v in pf.values())
N_BOTH = sum(v['both'] for v in pb.values()); N_HO = sum(v['human_only'] for v in pb.values()); N_AO = sum(v['ai_only'] for v in pb.values())
A_S = APP['by_dimension']['sexuality']

def lens(fig, theory):
    return f'<p class="lens"><span class="badge">Starts from</span> {fig} &nbsp; <span class="badge">Lens</span> {theory}</p>'

step7_dims = f'''
<article class="interp" id="s7-class"><h4>Class: hunger, display and the door</h4>
{lens('Fig. 1 (class evidenced in Blocks 1–2 only), Fig. 3 (class unlinked to any other theme), Fig. 5 (class the smallest dimension, ' + str(M['Class']['Class']) + ' items)', 'Bourdieu, cultural capital')}
<p>The narrator measures herself first in money. She lives in the &ldquo;hinterlands&rdquo; because {Q('that’s all you can afford on your salary')}, and at the hosts' door she wonders how many people of her age and pay get to {Q('disappear behind a door such as this')}. The drawing room completes the picture: stainless steel and white leather, coffee-table books lit &ldquo;just so&rdquo;, and an argument about Nietzsche. In Bourdieu's terms this is cultural capital on display: taste and intellectual talk working as signs of position (Bourdieu, 1984, 1986).</p>
<p>Step 6 shows class disappearing after Block 2. That result should not be read literally. What disappears is the explicit vocabulary of salary; class itself changes register. It becomes hunger (two bowls of potato chips presented as &ldquo;appetizers&rdquo;), unpaid labour (two hours in a hot kitchen) and taste (a biryani that is overcooked, undercooked and over-salted at once). The theme that carries it forward is <em>hunger, hospitality and unequal labour</em> (T16, {ev_count('T16')} items, tagged class <em>and</em> gender), which runs through Blocks 2–4. The hosts have the house and the furnishings but not the substance of hospitality: no ice, no food for hours, a meal that fails. Display and care have come apart.</p>
<p>The expensive door also anticipates the end of the story. What lies behind it is a marriage whose stability depends on something not being said. The class security the narrator envies and the closet she will later open belong to the same house.</p></article>

<article class="interp" id="s7-gender"><h4>Gender: authority as performance, hospitality as labour</h4>
{lens('Fig. 2 (male authority has the most evidence, ' + str(ev_count('T07')) + ' items), Fig. 3 (male authority and hunger/hospitality/labour share paragraphs)', 'Butler, gender performativity')}
<p>Mahesh's authority is staged rather than enforced. He sighs &ldquo;dramatically&rdquo;, smacks his knee &ldquo;theatrically&rdquo;, and the light on his shaved head gives him the look of {Q('an enlightened guru dispensing wisdom to his disciples')}. Butler's argument that gender is produced through repeated performances before an audience (Butler, 1990) fits closely, because his masculinity needs spectators: Tanu's eyes are filled {Q('more with the ardor of a devotee than the love of a wife')}, and Rani gazes at him as at a work of art.</p>
<p>Hospitality is where the performance turns into a politics of labour. Mahesh releases his wife from the kitchen as a gift ({Q('Tonight, you get full release from the kitchen.')}), but the work is not abolished; it is moved to another woman, the guest who is {Q('too well brought up to not offer help')}. In the kitchen her job is to chop and to listen: {Q('It was him listening to himself spread wisdom')}. The shared evidence between male authority and hospitality in Fig. 3 therefore points to a structure, not a coincidence: a benevolent patriarchy that takes credit for care whose cost falls on women. His protectiveness is the same possessiveness in another form, from the arm &ldquo;possessively gripped&rdquo; around Tanu's waist to his wedding-night list of {Q('what he would like to do to every man who has ever hurt Tanu')}.</p></article>

<article class="interp" id="s7-sexuality"><h4>Sexuality: compulsory heterosexuality and the open secret</h4>
{lens('Fig. 2 (heteronormativity and desire/jealousy, ' + str(ev_count('T06')) + ' items each), Fig. 4 (repressed desire marked by the human reader in Block 4)', 'Rich; Sedgwick; Warner; Ahmed on disgust')}
<p>The narrator's fantasy about Tanu is policed in the same breath that describes it. {Q('If you were a man')}, she could have liked Tanu's hair and praised her smile; since she is not, the thoughts are &ldquo;silly and pointless&rdquo;, and she adds: {Q('It certainly didn’t mean you were a lesbian.')} Rich's account of compulsory heterosexuality (1980) describes this exactly: desire for a woman becomes thinkable only by imagining oneself into the male position. The narrator's sexuality is never declared, and the reading should not declare it for her. What the text shows is a desire that can be held only in heteronormative grammar.</p>
<p>Her reaction to Pia and Projapoti, when {Q('your stomach churns')}, can be read through Ahmed's account of disgust as an emotion that draws a boundary between the self and what it fears becoming (Ahmed, 2004). The text leaves open whether the feeling is prejudice, envy or desire, and the extraction rightly keeps this as an ambiguity.</p>
<p>Tanu's past with Projapoti works as what Sedgwick calls the epistemology of the closet (Sedgwick, 1990): the office knows, the husband does not, and that unequal distribution of knowledge is a form of power that anyone in the know can use. The narrator reads Mahesh's ignorance as structural, not accidental: he {Q('cannot swallow the idea of his wife ever having been satisfied by a woman')}. Heteronormative marriage (Warner, 1991) here rests on an enforced forgetting, and the couple's plan ({Q('We’re trying to get pregnant.')}) is the project that would seal it.</p></article>

<article class="interp" id="s7-vuln"><h4>Emotional vulnerability: shame that moves</h4>
{lens('Fig. 1 (truth/disclosure and self-assertion appear only in Block 4), Fig. 4 (male vulnerability: absent from the key words, present in the full-text human interpretation and the AI extraction), Fig. 5 (largest overlap: gender and emotional vulnerability, ' + str(M['Gender']['Emotional vulnerability']) + ' items)', 'Ahmed, the cultural politics of emotion')}
<p>Ahmed argues that emotions are not private states but move between bodies and stick to objects (Ahmed, 2004). The narrator's shame has a precise origin, her mother's {Q('I cannot believe I gave birth to a spineless child.')}, and a precise object, the collapsed sandwich she chose to love. The story then shows the shame moving. When Mahesh insists that she stay, she obeys and answers her mother silently: {Q('No, Ma, I was not spineless.')} The sentence fails as it is spoken, because she has just given way again.</p>
<p>The disclosure comes at the moment she sees Mahesh as {Q('a man frightened that he might lose what he loves most in his life')}. She recognises vulnerability and strikes at it. Her question to Tanu converts her own accumulated humiliation (hunger, unpaid labour, Auro's look of pity, {Q('the kind one might reserve for a wretched dog')}) into Tanu's exposure. The narration refuses to make this heroic: its motives arrive only as excuses, {Q('Or at least that’s how you justify your words for days afterward')}. In this story, self-assertion appears only as betrayal. The researcher's full-text reading reaches the same point: her final act is {HQ('4', 'both empowerment and betrayal')}. The key-word label <em>emotional manipulation</em> and the AI's <em>self-assertion, spite and moral ambiguity</em> each catch only one side of it.</p></article>'''

positions = tbl(['Character', 'Class', 'Gender', 'Sexuality', 'Emotional vulnerability'], [
 ['<strong>Narrator</strong>', 'Lives alone in the &ldquo;hinterlands&rdquo;; envies the house; depends on the dhaba for food', 'Single woman; a guest who ends up doing kitchen work; checks how her body is seen', 'Undeclared; desire for women held in the conditional &ldquo;if you were a man&rdquo;; virgin, afraid of pregnancy', 'Maternal shame; hunger; Auro\'s pity; turns humiliation into exposure'],
 ['<strong>Tanu</strong>', 'Bungalow near Hauz Khas, secured through marriage', 'Devoted wife; released from the kitchen as a gift', 'Past relationship with Projapoti, hidden from her husband', 'Fears Rani\'s attention; is exposed at the end'],
 ['<strong>Mahesh</strong>', 'Owner and host; intellectual display', 'Performs authority, protection and benevolence', 'Cannot accept his wife\'s past with a woman', 'Afraid of losing Tanu'],
 ['<strong>Pia and Projapoti</strong>', 'A shared flat facing a golf course', 'Outside the marriage plot', 'An open couple whose visible desire the narrator polices', 'Their fights and affection are public; they leave first'],
])

app_line = (f'A supporting check (<a href="interpretation/appetite_check.py">appetite_check.py</a>) matched a {len(APP["lexicon"])}-word appetite lexicon '
            f'against every paragraph. Appetite words occur in {APP["paragraphs_with_appetite_words"]} of {APP["paragraphs_total"]} paragraphs '
            f'({APP["share_whole_story"]:.0%}) and in {A_S["with_appetite_words"]} of the {A_S["cited_paragraphs"]} paragraphs cited for sexuality '
            f'({A_S["share"]:.0%}), which is the same rate. Frequency cannot show the link: it rests on a few figurative transfers that close reading has to find. '
            f'This is the project\'s own rule (word counts are not evidence of themes) applied to its own hypothesis.')

compare = tbl(['Point of comparison', 'Human: preliminary key words', 'Human: full-text interpretation', 'AI extraction', 'What the comparison shows'], [
 ['Core arc', 'Class and alienation (B1), desire and heteronormativity (B2), people-pleasing and shame (B3), truth and betrayal (B4)', 'The same arc, read as a psychological progression from feeling inferior to using speech as a weapon', 'Same themes evidenced in the same blocks', f'Agreement in {N_BOTH} of 64 cells with the key words and {N_BOTH_FT} with the full text. The main architecture is legible to every reading; agreement is a baseline, not a discovery.'],
 ['Hunger, hospitality and labour', 'Not named', f'Block 3: the narrator {HQ("3", "is immediately assigned work in the kitchen")}, hungry and tired', f'{ev_count("T16")} items across Blocks 2–4', 'The human reader names the labour where it is most visible, in the kitchen. The AI traces it from the first unanswered hunger (Block 2) to the failed biryani (Block 4), turning an episode into a strand. In this interpretation that strand became the hinge between class and gender.'],
 ['Male vulnerability', 'Not named', f'Block 4: {HQ("4", "She recognizes Mahesh&#x27;s vulnerability")}', f'{ev_count("T15")} items, Block 4', 'Both full readings see it; only the key-word stage drops it. Seeing Mahesh as frightened reframes the disclosure as an attack on vulnerability, not a blow against power.'],
 ['Desire across blocks', 'Sexual anxiety in Block 2; repressed desire in Block 4', 'Block 2: lack of sexual experience; Block 4: virginity and sexual frustration', 'No block-local evidence for these two cells', f'The {N_HO_FT} human-only cells persist in the full text. The human reader carries the narrator\'s inner states (desire, shame) forward across blocks; the evidence-bound AI records them only where a sentence states them.'],
 ['Recurring social patterns', 'Each theme listed where it dominates', 'Each theme discussed where it peaks', 'Male authority, devotion and hospitality evidenced in three or four blocks each', f'Most of the {N_AO_FT} AI-only cells against the full text are recurrences of social patterns in blocks the human reading does not discuss them in. The AI is cumulative about social structure; the human reader is cumulative about inner life.'],
 ['The final question', '&ldquo;Emotional manipulation&rdquo;', f'{HQ("4", "both empowerment and betrayal")}, driven by anger, jealousy, sexual frustration, humiliation, insecurity and resentment', '&ldquo;Self-assertion, spite and moral ambiguity&rdquo;', 'The key word judges; the AI label hedges; the full human reading keeps both sides and names the motives most precisely. Here the human reading is the richest of the three.'],
 ['Class and sexuality', 'Treated in separate blocks', f'Linked in Block 4: {HQ("4", "Her social insecurity and sexual frustration influence the way she uses truth")}', '0 shared items (Fig. 5)', 'The human reader links them through the narrator\'s insecurity; close reading (7.3) links them through the language of appetite. The zero belongs to the coding scheme, not the story.'],
])

STEP7 = f'''<section id="step7"><h2>Step 7 · Interpretation and conclusions</h2>
<p>Step 6 described patterns; this step argues what they mean. Each claim below names the figure it starts from, the passages it rests on (paragraph IDs; every quotation on this page is checked against the corpus when the page is built) and the theory that frames it. These are interpretations, not results. Another reader could weigh the same evidence differently.</p>

<h3>7.1 The argument in brief</h3>
<div class="rq"><em>The Party</em> represents gender, sexuality, class and emotional vulnerability as one economy of appetite and display rather than four separate topics. Class is first felt as hunger and as envy of a door. Through the gendered work of hospitality it becomes a question of who cooks, who serves and who is listened to. Heterosexual marriage is the house that secures Tanu's class position, and the closet is its price. The narrator is single, poorer, sexually inexperienced and shamed since childhood. She can describe her own desire only in heteronormative terms, and when she finally asserts herself she does it by opening someone else's closet. The story's one act of &ldquo;spine&rdquo; is an act of exposure.</div>

<h3>7.2 Interpretation by dimension</h3>
{step7_dims}

<h3>7.3 Intersections: what Fig. 5 shows and what it misses</h3>
<p><strong>Gender is the hub.</strong> Gender carries the most evidence ({M['Gender']['Gender']} items) and overlaps most with emotional vulnerability ({M['Gender']['Emotional vulnerability']}) and sexuality ({M['Gender']['Sexuality']}). Read interpretively, gender is the channel through which class and sexuality become felt as vulnerability. The narrator is positioned at once by salary, marital status, sexual experience and family history. None of these alone explains her final question; together they do. This is the intersectional claim, used here in an extended sense. Crenshaw developed the concept to show how race and gender compound discrimination against Black women in law (Crenshaw, 1989, 1991). Applying it to class, sexuality and gender in a middle-class Delhi story borrows its structural insight (positions compound rather than add up) and not its original legal context.</p>
{positions}
<p class="small">Positions of the main characters on the four dimensions, summarised from the Step 5 extraction and the full text.</p>
<p><strong>The zero is a finding about the method.</strong> Class and sexuality share no evidence items because no theme in the coding scheme carries both tags. Close reading finds them meeting through appetite. The vendors' cries outside are {Q('lustful cries of the vendors')}; Pia and Projapoti's relationship has a {Q('ravenous passion')}; Mahesh {Q('cannot swallow')} his wife's past. The vocabulary of eating, which is where class is felt in this story, is also the vocabulary of desire. Hunger and the narrator's churning stomach at the sight of two women kissing come from the same body.</p>
<p class="note">{app_line}</p>
<p><strong>The ending stays open.</strong> In the last paragraph Tanu sits where the queer couple sat and {Q('picks up Pia’s half-empty glass of vodka and takes a sip')}. She breaks the pregnancy regimen (water and orange juice all evening) and moves into the space that Pia and Projapoti left. The gesture can be read as withdrawal from the heterosexual project, as grief, or as a refusal to look at her husband. The story stops before deciding, and the interpretation should too.</p>
<div class="flow" aria-label="Interpretive model"><div><b>CLASS</b>Salary, the door, hunger</div><div><b>GENDER</b>Who cooks, who serves, who is heard</div><div><b>SEXUALITY</b>The closet; &ldquo;if you were a man&rdquo;</div><div><b>VULNERABILITY</b>Shame turned into spite</div><div style="background:#f3efe3"><b>BLOCK 4</b>Disclosure</div></div>
<p class="small">Interpretive model: a conceptual summary of the argument, not a data figure.</p>

<h3>7.4 What synthetic reading revealed</h3>
{compare}
<p>Synthetic reading worked here as a dialogue, not a vote, and the most useful outputs were the differences. Comparing three readings rather than two matters: against the key words alone, the AI seemed to find themes the human reader had missed (male vulnerability, unequal labour), but the full-text interpretation shows that she saw both. The gap lay in the compression from reading to key words, not in the reader. What remains distinctive is the direction of each reader's memory. The AI follows social patterns (authority, hospitality, devotion) through every block in which they recur; the human reader follows the narrator's inner life (desire, shame, the need to prove she is not &ldquo;spineless&rdquo;) across blocks where no single sentence states it. The researcher's own summary, that the story presents speech as {HQ('overall', 'a form of both agency and retaliation')}, and the argument of 7.1 meet at the same point.</p>

<h3>7.5 Conclusions</h3>
<ol>
<li><strong>How does the story represent the intersections of gender, sexuality, class and emotional vulnerability?</strong> Through a single evening in which display and hunger, protection and possession, and the closet and its disclosure are bound together. Gender is the medium. Marriage is the institution that holds class security and sexual silence in place. Vulnerability, passed from mother to daughter and from the narrator to Tanu, is the force that breaks the structure open.</li>
<li><strong>How can synthetic reading reveal these structures?</strong> By making each reader's selections visible and checkable. The AI traced recurring social patterns across all four blocks; the human reader traced the narrator's inner life across blocks and judged the final act most precisely; comparing the full-text interpretation with the key words showed that apparent AI &ldquo;discoveries&rdquo; can be artefacts of how a human reading is summarised. A dataset of verified quotations made every claim traceable to the text, and the coding's blind spot (class and sexuality) showed where close reading had to take over. Synthetic reading did not produce the interpretation; it sharpened the questions that close reading then answered.</li>
</ol>

<h3>7.6 Limits of this interpretation and further work</h3>
<ul>
<li>One model and one run, and one human reader. Coding the human interpretation to themes is itself an analytical step; a second coder would test it.</li>
<li>The theoretical frames are largely Euro-American. The story is set in contemporary New Delhi; reading it alongside Indian scholarship on same-sex love (e.g. Vanita &amp; Kidwai, 2000) and against the legal context after the Supreme Court read down Section 377 of the Indian Penal Code in 2018 (<em>Navtej Singh Johar v. Union of India</em>, 2018) would test whether these frames fit.</li>
<li>Next steps: run the same prompt with local models (<code>Theme_JSON.py --source local-llm</code>) several times to test stability; add a second human coder for the key-word mapping and the full-text coding; consider a theme tagged with both class and sexuality and see whether Fig. 5 changes.</li>
</ul>
<p><a href="research/interpretation_step7.md">Step 7 as markdown</a> (same text, for the thesis document).</p>
</section>'''

REFS += [
 'Navtej Singh Johar v. Union of India, (2018) 10 SCC 1 (Supreme Court of India, September 6, 2018).',
 'Vanita, R., &amp; Kidwai, S. (Eds.). (2000). <em>Same-sex love in India: Readings from literature and history</em>. St. Martin\'s Press.',
]
REFS.sort(key=lambda r: re.sub(r'<[^>]+>', '', r).lower())
refs = ''.join(f'<li>{r}</li>' for r in REFS)

NAV = [('overview', 'Overview'), ('context', 'Context'), ('step1', 'Step 1'), ('step2', 'Step 2'), ('step3', 'Step 3'), ('step4', 'Step 4'),
       ('step5', 'Step 5'), ('step6', 'Step 6'), ('step7', 'Step 7'), ('references', 'References'), ('limits', 'Limits & ethics')]
nav = ''.join(f'<a href="#{i}">{l}</a>' for i, l in NAV)

TEMPLATE = r'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Synthetic Reading: The Party — Digital Humanities research project</title>
<meta name="description" content="A human–AI comparative analysis of Sayantani Dasgupta's short story The Party (Steps 1–7).">
<style>
:root{--bg:#f7f5f0;--ink:#1f2a44;--mute:#566079;--card:#fff;--line:#d9d5c9;--acc:#2f5d8a;--acc2:#8a4f3a;--g:#7a4e9e;--s:#c0504d;--c:#b4801a;--e:#2f7f93}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:64px}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.65 Georgia,"Times New Roman",serif}
h1,h2,h3,h4,nav,button,.tag,.dim,th,.pid,.badge{font-family:"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif}
nav{position:sticky;top:0;z-index:10;background:rgba(247,245,240,.96);backdrop-filter:blur(6px);border-bottom:1px solid var(--line);display:flex;gap:2px;overflow-x:auto;padding:0 12px;white-space:nowrap}
nav a{color:var(--ink);text-decoration:none;padding:16px 11px;font-size:14px;border-bottom:3px solid transparent}
nav a:hover,nav a.on{border-bottom-color:var(--acc2);color:var(--acc2)}
header.hero{padding:56px 20px 40px;background:linear-gradient(#ece7da,#f7f5f0);border-bottom:1px solid var(--line)}
.wrap{max-width:1040px;margin:0 auto;padding:0 20px}
h1{font-size:clamp(28px,4.6vw,44px);line-height:1.15;margin:.2em 0 .3em;font-weight:700}
h2{font-size:28px;margin:0 0 .6em;padding-top:8px;border-top:2px solid var(--ink)}
h3{font-size:20px;margin:1.6em 0 .4em;color:var(--acc)}h4{margin:.9em 0 .3em;font-size:16px}
section{padding:44px 0 8px}
.kicker{font:600 13px "Segoe UI",system-ui,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:var(--acc2)}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px 22px;margin:16px 0}
.rq{border-left:5px solid var(--acc2);background:#fff;padding:14px 20px;margin:18px 0;font-size:19px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}
.badge{display:inline-block;font-size:12px;padding:2px 9px;border-radius:99px;background:#e6edf5;color:var(--acc);margin:0 4px 4px 0}
.badge.warn{background:#f7e8d8;color:#8a4f3a}
.tablewrap{overflow-x:auto;margin:12px 0;border:1px solid var(--line);border-radius:8px;background:#fff}
table{border-collapse:collapse;width:100%;font-size:14.5px;min-width:560px}th,td{padding:9px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{background:#eee9dc;font-size:13px}table.passages td:nth-child(2){min-width:320px}
.pid{font-size:11.5px;background:#e8eaf0;border-radius:4px;padding:1px 6px;color:var(--mute);margin-right:4px}
.note,.small{color:var(--mute);font-size:14.5px}
pre,code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px}
pre{background:#1f2433;color:#e8e9f0;padding:16px;border-radius:8px;overflow:auto;max-height:420px;white-space:pre-wrap;word-break:break-word}
code{background:#ece8dc;padding:1px 5px;border-radius:4px}pre code{background:none;padding:0}
button,.btn{font:600 14px "Segoe UI",system-ui,sans-serif;background:var(--ink);color:#fff;border:0;padding:9px 16px;border-radius:7px;cursor:pointer;text-decoration:none;display:inline-block}
button:hover,.btn:hover{background:var(--acc2)}.btn.alt{background:#fff;color:var(--ink);border:1px solid var(--ink)}
.tabs{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}.tab{background:#fff;color:var(--ink);border:1px solid var(--line)}.tab.on{background:var(--ink);color:#fff}
.pane{display:none}.pane.on{display:block}
.theme{background:#fff;border:1px solid var(--line);border-radius:8px;padding:6px 18px 10px;margin:12px 0}.theme h4 small{color:var(--mute);font-weight:400}
.ev{padding-left:18px;margin:.4em 0}.ev li{margin:.3em 0}
.tag{font-size:11px;border-radius:4px;padding:1px 6px;margin-left:4px}.tag.explicit{background:#dcebdd;color:#245a2b}.tag.inferential{background:#f6e6c5;color:#7a5a12}
.dim{font-size:11.5px;border-radius:99px;padding:2px 9px;color:#fff;margin-right:4px}
.d-gender{background:var(--g)}.d-sexuality{background:var(--s)}.d-class{background:var(--c)}.d-emotional_vulnerability{background:var(--e)}
figure.fig{margin:22px 0}figure.fig img{width:100%;height:auto;border:1px solid var(--line);border-radius:6px;background:#fff}
figcaption{margin:10px 0 4px}dl{margin:0}dt{font:600 13px "Segoe UI",system-ui,sans-serif;color:var(--acc2);margin-top:10px;text-transform:uppercase;letter-spacing:.05em}dd{margin:2px 0 0}
.flow{display:flex;flex-wrap:wrap;gap:8px;align-items:stretch;margin:14px 0}.flow div{flex:1 1 120px;background:#fff;border:1px solid var(--line);border-radius:8px;padding:10px;font:14px "Segoe UI",system-ui,sans-serif;text-align:center}
.flow div b{display:block;color:var(--acc2);font-size:12px;letter-spacing:.06em}
.chartbox{position:relative;height:340px}
.interp{background:#fff;border:1px solid var(--line);border-left:4px solid var(--acc);border-radius:8px;padding:6px 22px 12px;margin:16px 0}.interp h4{font-size:18px;color:var(--ink)}
.arrows{list-style:none;padding-left:0}.arrows li{padding:4px 0 4px 14px;border-left:3px solid var(--acc);margin:4px 0}
.lens{font-size:14px;color:var(--mute);margin:.2em 0 .8em}.lens .badge{margin-right:2px}
footer{margin-top:60px;padding:30px 0;border-top:1px solid var(--line);color:var(--mute);font-size:14px}
#toast{position:fixed;bottom:20px;right:20px;background:var(--ink);color:#fff;padding:10px 16px;border-radius:8px;font:14px "Segoe UI",sans-serif;opacity:0;transition:.3s;pointer-events:none}#toast.show{opacity:1}
@media(max-width:600px){body{font-size:16px}.card{padding:14px}h2{font-size:24px}}
</style></head><body>
<nav aria-label="Sections">@@NAV@@</nav>
<header class="hero" id="overview"><div class="wrap">
<div class="kicker">Digital Humanities · MA research project · Steps 1–7</div>
<h1>Synthetic Reading: A Human–AI Comparative Analysis of <em>The Party</em> by Sayantani Dasgupta</h1>
<p><strong>Author of the literary text:</strong> Sayantani Dasgupta &nbsp;·&nbsp; <strong>Researcher:</strong> Sangita Chatterjee, MA Digital Humanities, IIT (ISM) Dhanbad &nbsp;·&nbsp; <strong>Field:</strong> Digital Humanities</p>
<div class="rq"><strong>Research question.</strong> How does Sayantani Dasgupta's <em>The Party</em> represent the intersections of gender, sexuality, class and emotional vulnerability, and how can synthetic reading reveal these socio-cultural structures through human–AI comparative literary analysis?</div>
<h3 style="margin-top:20px">Abstract</h3>
<p>This project reads one short story, a second-person account of an evening at a former colleague's home in Delhi, in two ways. The researcher reads the opening of each of four blocks (the partial reading), records preliminary themes for each block and writes a full-text interpretation. An AI reader then extracts themes from the full text under a strict prompt that demands exact quotations and separates explicit evidence from inference. Every quotation attached to a theme (<strong>@@NQ@@</strong>) is machine-checked against the corpus. Five visualisations compare the human and AI readings and map how gender, sexuality, class and emotional vulnerability share evidence. The aim is to see what each reader notices, not to replace interpretation. Step 7 interprets these patterns through theories of performativity, compulsory heterosexuality, the closet, cultural capital and affect, and argues that the story binds its four dimensions into one economy of appetite and display.</p>
<h3>Objectives</h3>
<ol><li>Document the partial reading of four blocks from the highlighted passages.</li><li>Compare the researcher's preliminary themes and full-text interpretation with a full-text AI extraction.</li><li>Build a clean corpus, a reusable prompt and a validated structured dataset.</li><li>Visualise distribution, co-occurrence, agreement and intersections without treating word counts as proof.</li><li>Interpret the patterns through selected theories and answer the research question.</li></ol>
<h3>Research overview</h3>
<div class="flow"><div><b>STEP 1</b>Partial reading</div><div><b>STEP 2</b>Method &amp; reflexivity</div><div><b>STEP 3</b>Preprocessing</div><div><b>STEP 4</b>Prompt</div><div><b>STEP 5</b>Extraction JSON</div><div><b>STEP 6</b>Visualisation</div><div style="background:#f3efe3"><b>STEP 7</b>Interpretation</div></div>
</div></header>
<main class="wrap">
<section id="context"><h2>Research context</h2>
<p><strong>Background.</strong> <em>The Party</em> (Sayantani Dasgupta) is narrated in the second person, present tense. A woman arrives hungry at a dinner party hosted by a former colleague, Tanu, and her husband Mahesh, among former colleagues Pia, Projapoti, Rani and Auro. Over one evening the story moves from class envy and bodily self-consciousness to a disclosure that ends the party.</p>
<p><strong>Research problem.</strong> A human reading and an AI reading of the same text may notice different structures. Comparing them can show what a close reading foregrounds, what a systematic pass adds, and where the AI flattens ambiguity.</p>
<p><strong>Selected text.</strong> <em>The Party</em> by Sayantani Dasgupta, about 4,300 words, 73 paragraphs, supplied by the researcher.</p>
<h3>Four-block structure (preserved from the researcher's document)</h3>
<div class="grid">@@BLOCKCARDS@@</div>
<h3>Document audit</h3><p class="note">Result of checking the uploaded document before any work began.</p>@@AUDIT@@
</section>

<section id="step1"><h2>Step 1 · Partial reading</h2>
<h3>Four-block division and word-count verification</h3>@@WC@@
<p class="note">Raw counts are whitespace-separated words on the uploaded file. Block 1's stated 1,064 includes the title and byline (4 words). Clean-corpus counts are slightly lower because preprocessing re-joins spaced abbreviations such as "T V" and "O B G Y N".</p>
<h3>Method</h3>
<ol><li>Divide the text into four approximately equal blocks.</li><li>Read the opening passage of each block (about @@PCT@@ of its words) and highlight it in the document. These highlighted passages are the partial reading.</li><li>Record the exact passages with block and paragraph IDs, and form initial impressions from them alone.</li><li>Check which of the researcher's key words for each block are already visible in the highlighted passages.</li></ol>
<p>The highlights are read directly from the researcher's document (<a href="source/The_Party_divided_into_4_blocks.docx">The_Party_divided_into_4_blocks.docx</a>) by <a href="partial_reading/extract_highlights.py">extract_highlights.py</a>, which maps each highlighted paragraph to its ID and checks it word for word against the corpus. Every highlighted passage is a complete paragraph. Record: <a href="partial_reading/partial_reading.txt">partial_reading.txt</a>.</p>
@@COV@@
@@PR@@
<h3>What the partial reading already shows</h3>
@@KW@@
<p>The partial reading captures Block 1 almost completely: @@KW1@@ of its ten key words are visible in the opening passage. Block 2 is different. Only @@KW2@@ of ten are visible, because the passages on Pia and Projapoti and the narrator's fantasy about Tanu come after the highlighted opening. The researcher's block titles therefore rest on her reading of each whole block, while the partial reading records how each block first presents itself. In the highlighted passages, hunger, hospitality and male talk are more prominent than sexuality, which anticipates a strand that the AI extraction later develops (Step 5).</p>
<h3>Preliminary themes (human, from the researcher's document)</h3>@@HUMAN@@
</section>

<section id="step2"><h2>Step 2 · Research methodology and reflexivity</h2>
<div class="grid">
<div class="card"><h4>Research problem</h4><p>How do a human and an AI reader identify and weigh the story's intertwined class, gender, sexuality and emotional structures?</p></div>
<div class="card"><h4>Objectives</h4><p>Documented partial reading; evidence-bound extraction; transparent comparison; visual mapping of intersections.</p></div>
<div class="card"><h4>Research questions</h4><p>(1) How does the story represent the four dimensions? (2) Where do human and AI readings agree or diverge? (3) What do the shared-evidence patterns suggest for Step 7?</p></div></div>
<h3>Research design and approach</h3>
<p>Qualitative and interpretive, close to reflexive thematic analysis (Braun &amp; Clarke, 2006). Computation organises interpretations (counts of verified quotations, shared-paragraph co-occurrence, agreement tables), in the spirit of algorithmic criticism (Ramsay, 2011). Word frequency is not used as evidence of a theme.</p>
<h3>Theoretical frameworks, used selectively</h3>
@@THEORY@@
<h3>Researcher positionality and reflexivity</h3>
<p>The researcher reads a story set in contemporary New Delhi from within the Indian academic and social context it depicts. That helps with details (a dhaba, Hindi films, expectations around marriage and pregnancy) but may also carry assumptions about class, marriage and sexuality. Her preliminary themes were written before the AI extraction and are kept unchanged so that the comparison is honest.</p>
<h3>Human reading versus AI-assisted reading</h3>
@@HVA@@
<p><a href="research/methodology.md">Full methodology (markdown)</a></p>
</section>

<section id="step3"><h2>Step 3 · Text upload and preprocessing</h2>
<h3>Corpus information</h3>
<p>File: <a href="corpus/The_Party.txt">corpus/The_Party.txt</a>. Four blocks marked <code>[[BLOCK n]]</code>, 73 paragraphs, 303 sentences, @@TOK@@ tokens (clean corpus). Original wording, paragraph order and curly quotes are retained.</p>
<h3>Workflow</h3>
<div class="flow"><div><b>1</b>Load blocks</div><div><b>2</b>Clean layout noise</div><div><b>3</b>Paragraph IDs (B2P12)</div><div><b>4</b>Sentence split</div><div><b>5</b>Tokenise (lower-case, token layer only)</div><div><b>6</b>Frequencies per block</div></div>
<ul><li><strong>Text cleaning:</strong> normalises hair-space and non-breaking spaces; re-joins spaced abbreviations (T V → TV, P D A → PDA, O B G Y N → OBGYN, T M I → TMI); removes spaces before punctuation.</li>
<li><strong>Paragraph preservation:</strong> every paragraph keeps an ID so quotations can be located and checked.</li>
<li><strong>Tokenisation and normalisation:</strong> lower-casing happens only in the token layer; the clean text keeps case.</li>
<li><strong>Stopwords:</strong> only 29 function words are dropped. "You/your", gendered words (man, woman, wife, husband), desire and emotion words and negations are kept, because second-person address and gendered vocabulary are analytically important.</li></ul>
<pre><code>@@CODE@@</code></pre>
<p>Script: <a href="preprocessing/preprocess.py">preprocess.py</a> (standard library only; runs locally and in Google Colab). Outputs in <code>results/</code>: corpus_blocks.json, sentences.csv, word_frequencies.csv, corpus_summary.json.</p>
</section>

<section id="step4"><h2>Step 4 · AI prompt engineering</h2>
<h3>Feature-extraction framework</h3>
<p>The prompt asks for 14 kinds of features per block (themes and subthemes, gender, sexuality and identity, class, patriarchal power, affect, relationships, conflicts, social conditioning, internalised prejudice, symbolism, narrative perspective, character development, textual evidence) and tags each theme with the four dimensions.</p>
<h3>Rules that control the extraction</h3>
<ul><li>Every theme needs verbatim evidence (quotation ≤ 25 words and a paragraph ID).</li><li>Each evidence item is labelled <em>explicit</em> or <em>inferential</em>.</li><li>Each classification is explained; overlapping themes are listed; ambiguity is kept in an <code>ambiguities</code> field.</li><li>No invented characters, quotations or events; the narrator stays unnamed.</li><li>Output is one JSON object.</li></ul>
<h3>Final reusable prompt</h3>
<p><button id="copyPrompt" type="button">Copy prompt to clipboard</button> <a class="btn alt" href="prompts/prompt.txt" download>Download prompt.txt</a></p>
<pre id="promptText"><code>@@PROMPT@@</code></pre>
<h3>Extraction process</h3>
<p>The placeholder <code>&lt;&lt;STORY_TEXT&gt;&gt;</code> is replaced with the corpus; the model's JSON reply is validated by <code>Theme_JSON.py</code>, which rejects any quotation that is not an exact substring of its paragraph.</p>
</section>

<section id="step5"><h2>Step 5 · Thematic extraction and structured JSON</h2>
<p><a href="extraction/Theme_JSON.py">Theme_JSON.py</a> validates the output and also contains a route for running the same prompt with a local LLM (Ollama). All @@NQ@@ quotations passed verification.</p>
<p><a class="btn" href="results/theme_extraction.json" download>Download theme_extraction.json</a> <a class="btn alt" href="extraction/Theme_JSON.py" download>Download Theme_JSON.py</a></p>
<h3>JSON structure</h3><pre><code>@@STRUCT@@</code></pre>
<p class="small">One real theme record from Block 1 (first evidence item only):</p><pre><code>@@SAMPLE@@</code></pre>
<h3>Human versus AI thematic categories</h3>
<p>The researcher's key phrases (human) are mapped to 16 canonical themes so that they can be compared. The mapping is an analytical choice stored in the JSON.</p>@@VOCAB@@
<p>Human and AI findings are stored separately: <code>blocks[].human_generated_themes</code> holds the researcher's phrases; <code>blocks[].major_themes</code> holds AI themes. The researcher's full-text interpretation is kept in <code>results/human_interpretation.json</code> and coded to the same canonical themes in <code>blocks[].human_full_text_themes</code>, each code with an excerpt from her text.</p>
<h3>Human full-text interpretation (researcher)</h3>
<p class="note">The researcher's interpretation of each block and of the whole story, as written in her document (<a href="results/human_interpretation.json">human_interpretation.json</a>). The themes listed under each block are the canonical themes it discusses, as coded for Fig. 4.</p>
<div class="tabs" role="tablist">@@HTABS@@</div>@@HPANES@@
<h3>Four-block thematic extraction with evidence-based interpretation</h3>
<div class="tabs" role="tablist">@@TABS@@</div>@@PANES@@
</section>

<section id="step6"><h2>Step 6 · Computational analysis and visualisation</h2>
<p>All figures are generated by <a href="visualization/visualization.py">visualization.py</a> from <code>results/theme_extraction.json</code> and saved as 300-dpi PNG in <code>figures/generated_visualisations/</code>. No value was typed in by hand; plotted numbers are in <code>results/figure_data.json</code>.</p>
@@FIGS@@
<div class="card"><h4>Interactive view: evidence by dimension and block <small class="small">(Chart.js, needs internet; the PNG in Fig. 5B shows the same data)</small></h4><div class="chartbox"><canvas id="dimChart" aria-label="Evidence items per dimension per block"></canvas></div><p id="chartFallback" class="small" style="display:none">Chart.js could not be loaded (no internet). See Fig. 5, panel B.</p></div>
<h3>Computational analysis and literary interpretation</h3>
<p>The figures organise a reading; they do not make an argument. A count shows where the extraction found support, a network shows shared evidence, a heat-map shows agreement. Whether those patterns mean anything for gender, sexuality or class depends on close reading and theory, which is the work of Step 7.</p>
<p class="note">The interpretation of these patterns is in <a href="#step7">Step 7</a>. A fuller descriptive summary of Step 6 is in <a href="research/findings_up_to_step6.md">findings_up_to_step6.md</a>.</p>
</section>

@@STEP7@@

<section id="references"><h2>References</h2>
<p class="note">APA 7th edition.</p>
<ol class="refs">@@REFS@@</ol></section>

<section id="limits"><h2>Limitations and research ethics</h2>
<div class="grid">
<div class="card"><h4>Partial reading</h4><p>The highlighted passages are the opening of each block (about @@PCT@@ of the words). First impressions from openings can over-weight how a block begins and miss turns that come later, as Block 2 shows.</p></div>
<div class="card"><h4>AI hallucination</h4><p>Quotations are machine-verified against the corpus; interpretations are not and remain arguments. Verified quotations can still be placed under a theme that a different reader would reject.</p></div>
<div class="card"><h4>Bias in LLM interpretation</h4><p>Models trained mostly on English and Western sources may read gender, sexuality and class in an Indian setting through foreign frames. The narrator's sexuality is never stated in the text; the extraction treats it as shown (denial, fantasy, ambivalence), not declared.</p></div>
<div class="card"><h4>Contextual limits</h4><p>One short story read without author context, publication context or reception. <em>Explicit</em>/<em>inferential</em> labels describe the quotation, so 88 of 93 "explicit" does not mean the themes are uncontested.</p></div>
<div class="card"><h4>Small corpus</h4><p>About 4,300 words: counts describe this extraction of this story, not general patterns. Dimension tags are fixed per theme, so Fig. 5 partly reflects the coding scheme.</p></div>
<div class="card"><h4>Copyright and responsible use</h4><p>The story is a copyrighted work supplied by the researcher for study. If this repository is public, remove <code>corpus/The_Party.txt</code> (and the passages shown above) or obtain permission; keep only short quotations. Do not upload the story to third-party services without permission.</p></div>
<div class="card"><h4>One-run, one-model</h4><p>A single run of one model is not a replication. Running <code>Theme_JSON.py --source local-llm</code> with other models would test stability.</p></div>
</div>
</section>
</main>
<footer><div class="wrap">Synthetic Reading · <em>The Party</em> · Steps 1–7 · Built from the repository's data files by <code>visualization/build_site.py</code>. External library: Chart.js via CDN (internet needed only for the interactive chart); everything else works offline.</div></footer>
<div id="toast" role="status"></div>
<script>
const toast=m=>{const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)};
document.getElementById('copyPrompt').addEventListener('click',async()=>{const txt=document.getElementById('promptText').innerText;
 try{await navigator.clipboard.writeText(txt);toast('Prompt copied')}catch(e){const r=document.createRange();r.selectNodeContents(document.getElementById('promptText'));const s=getSelection();s.removeAllRanges();s.addRange(r);try{document.execCommand('copy');toast('Prompt copied')}catch(_){toast('Select and copy manually')}}});
document.querySelectorAll('.tabs').forEach(g=>{const bs=[...g.querySelectorAll('.tab')];bs.forEach(b=>b.addEventListener('click',()=>{bs.forEach(x=>{x.classList.remove('on');document.getElementById(x.dataset.t).classList.remove('on')});b.classList.add('on');document.getElementById(b.dataset.t).classList.add('on')}))});
document.getElementById('blk1').classList.add('on');document.getElementById('hblk1').classList.add('on');
const links=[...document.querySelectorAll('nav a')];const secs=links.map(a=>document.querySelector(a.getAttribute('href')));
addEventListener('scroll',()=>{let i=0;secs.forEach((s,k)=>{if(s&&s.getBoundingClientRect().top<120)i=k});links.forEach((a,k)=>a.classList.toggle('on',k===i))},{passive:true});
const D=@@CHARTDATA@@;
function draw(){const cols={'Gender':'#7a4e9e','Sexuality':'#c0504d','Class':'#b4801a','Emotional vulnerability':'#2f7f93'};
 new Chart(document.getElementById('dimChart'),{type:'bar',data:{labels:D.labels,datasets:Object.keys(D.dims).map(k=>({label:k,data:D.dims[k],backgroundColor:cols[k]}))},options:{responsive:true,maintainAspectRatio:false,plugins:{title:{display:true,text:'Evidence items tagged by dimension, per block'}},scales:{y:{beginAtZero:true,title:{display:true,text:'Evidence items'}}}}})}
(function(){const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js';s.onload=draw;s.onerror=()=>{document.querySelector('.chartbox').style.display='none';document.getElementById('chartFallback').style.display='block'};document.head.appendChild(s)})();
</script></body></html>'''

block_cards = ''.join(
    f'<div class="card"><h4>Block {b["block_id"]}</h4><p><strong>{E(b["human_generated_themes"]["title"])}</strong></p>'
    f'<p class="small">{STATED[b["block_id"]]:,} words (stated) · {S[str(b["block_id"])]["paragraphs"]} paragraphs</p></div>' for b in T['blocks'])
theory = tbl(['Framework', 'Why it is relevant to this story'], [
 ['Intersectionality (Crenshaw, 1989, 1991)', 'Salary, gender and sexuality shape the narrator\'s position together; class envy and bodily self-surveillance are linked.'],
 ['Gender performativity (Butler, 1990)', 'Mahesh\'s staged authority, Tanu\'s devotion and the narrator\'s body-checking read as repeated, regulated performances.'],
 ['Heteronormativity and queer theory (Rich, 1980; Sedgwick, 1990; Warner, 1991)', 'Desire for a woman is imaginable only "if you were a man"; Mahesh cannot accept his wife\'s past.'],
 ['Cultural capital (Bourdieu, 1984, 1986)', 'Intellectual talk, furnishing and hospitality work as display.'],
 ['Affect theory (Ahmed, 2004)', 'Shame, envy and disgust circulate between characters and stick to objects (food, bodies, the mother\'s remark).'],
 ['Feminist and queer literary criticism', 'Reading practices for who speaks, whose labour is invisible and what is closeted.']])
hva = tbl(['', 'Human reading', 'AI-assisted reading'], [
 ['Strength', 'Situated knowledge, ethical judgment, sensitivity to tone', 'Systematic coverage of every paragraph, consistent coding, explicit evidence'],
 ['Risk', 'Selective attention, impressionistic claims', 'Hallucinated quotations, flattened ambiguity, training-data bias'],
 ['Safeguard here', 'Partial reading is documented; claims are tied to passages', 'Every quotation machine-checked; inference labelled; ambiguity kept']])
code = '\n\n'.join(func_src(n) for n in ('clean_text', 'split_sentences', 'tokenize'))
out = TEMPLATE
for k, v in {'@@NAV@@': nav, '@@NQ@@': str(F['totals']['evidence_items']), '@@BLOCKCARDS@@': block_cards, '@@AUDIT@@': audit, '@@WC@@': wc_table,
             '@@PR@@': pr_table, '@@HUMAN@@': human_table, '@@THEORY@@': theory, '@@HVA@@': hva, '@@TOK@@': f"{S['total']['tokens']:,}",
             '@@CODE@@': E(code), '@@PROMPT@@': E(PROMPT), '@@STRUCT@@': E(struct), '@@SAMPLE@@': E(sample_json), '@@VOCAB@@': vocab_table,
             '@@TABS@@': tabs, '@@PANES@@': ''.join(panes), '@@FIGS@@': fig_cards, '@@REFS@@': refs, '@@HTABS@@': htabs, '@@HPANES@@': ''.join(hpanes), '@@COV@@': cov_table, '@@KW@@': kw_table, '@@PCT@@': f"{PST['total']['share_of_words']:.0%}", '@@KW1@@': str(len(OBS['1']['keywords_visible'])), '@@KW2@@': str(len(OBS['2']['keywords_visible'])), '@@CHARTDATA@@': chart_data, '@@STEP7@@': STEP7}.items():
    out = out.replace(k, v)
assert '@@' not in out, re.findall(r'@@\w+@@', out)
open(os.path.join(ROOT, 'index.html'), 'w', encoding='utf-8').write(out)
json.dump({'note': 'Every quotation used in Step 7, verified as an exact substring of exactly one corpus paragraph.', 'quotes': STEP7_QUOTES},
          open(os.path.join(ROOT, 'results', 'step7_quotes_verified.json'), 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
print(len(STEP7_QUOTES), 'Step 7 quotations verified')
print('index.html written', len(out) // 1024, 'KB')
