# Synthetic Reading: A Human–AI Comparative Analysis of *The Party* by Sayantani Dasgupta

MA Digital Humanities research project (Steps 1–7). Open `index.html` for the full write-up, or publish it with GitHub Pages.

## What is here
```
index.html                      research website (all seven steps)
source/                         The_Party_divided_into_4_blocks.docx (researcher's document: blocks, highlights, key words, human interpretation)
corpus/The_Party.txt            story text, four blocks marked [[BLOCK n]]  (see copyright note)
partial_reading/                extract_highlights.py, make_partial_reading.py, selected_passages.json, partial_reading.txt
prompts/prompt.txt              reusable LLM extraction prompt
preprocessing/preprocess.py     cleaning, paragraph IDs, sentences, tokens, frequencies
extraction/                     extract_human_interpretation.py; Theme_JSON.py (extraction data + validation, optional local-LLM route)
results/                        theme_extraction.json, human_interpretation.json, figure_data.json, corpus_*.json, step7_*.json, *.csv
visualization/                  visualization.py (5 figures), build_site.py (builds index.html)
interpretation/                 appetite_check.py (Step 7 supporting check)
figures/generated_visualisations/   fig1–fig5 PNG, 300 dpi
research/                       methodology.md, findings_up_to_step6.md, interpretation_step7.md
```

## Reproduce (Python 3.9+, also works in Google Colab)
```bash
pip install -r requirements.txt
python preprocessing/preprocess.py
python partial_reading/extract_highlights.py        # Step 1: highlighted passages from the .docx
python partial_reading/make_partial_reading.py
python extraction/extract_human_interpretation.py  # researcher's full-text interpretation from the .docx
python extraction/Theme_JSON.py          # validates every quotation and every human-coding excerpt
python visualization/visualization.py
python interpretation/appetite_check.py   # Step 7 supporting check
python visualization/build_site.py       # regenerates index.html; verifies every Step 7 quotation
```
Run all commands from the repository root. Local LLM (optional, not run in the original build): start Ollama and run
`python extraction/Theme_JSON.py --source local-llm --model llama3.1:8b` (writes `results/theme_extraction_llm.json`).

## Data notes
- Partial reading: the passages highlighted in the researcher's document, the opening of each block (1164 of 4337 words, 27%).
- The AI extraction (Claude, claude-sonnet-5-5) follows `prompts/prompt.txt`; all 93 theme quotations are machine-verified against the corpus.
- The researcher's full-text interpretation is coded to the same 16 themes (`blocks[].human_full_text_themes`), each code with a verified excerpt from her text.
- All 22 Step 7 quotations are machine-verified (`results/step7_quotes_verified.json`).

## Copyright
*The Party* is a copyrighted work supplied by the researcher for study. If you make this repository public, delete `corpus/The_Party.txt` and `source/The_Party_divided_into_4_blocks.docx` (and the passage text in `index.html`/`partial_reading/`) or obtain permission, and keep only short quotations. A private repository avoids the issue; GitHub Pages from a private repo needs a paid plan, so the simplest public option is to remove the corpus and passages first.

## Upload to GitHub
1. Create a new repository on github.com (e.g. `Synthetic-Reading-The-Party`).
2. Easiest: click **Add file → Upload files**, drag in the *contents* of the unzipped folder (keep the sub-folders), and commit.
   Or with git: `git init && git add . && git commit -m "Initial commit" && git branch -M main && git remote add origin <repo-url> && git push -u origin main`.

## Enable GitHub Pages
Repository **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: `main`, folder `/ (root)` → Save.** After a minute the site is live at

`https://<your-github-username>.github.io/Synthetic-Reading-The-Party/`  *(placeholder until you publish)*

## Internet requirements
`index.html` is self-contained (embedded CSS and JS). Only the optional interactive chart in Step 6 loads Chart.js from `cdn.jsdelivr.net`; without internet it is hidden and the PNG figures still show. All links are relative and work on GitHub Pages and when opened from a local folder.
