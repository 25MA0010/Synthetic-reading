# Methodology — Synthetic Reading: A Human–AI Comparative Analysis of *The Party* by Sayantani Dasgupta

## 1. Research problem
Short stories compress social structures into small domestic scenes. In *The Party*, a second-person narrator spends an evening at a former colleague's home and the story brings together class envy, a married couple's gender dynamics, a concealed same-sex past and the narrator's own repressed desire. It is unclear how a human reader and an AI reader would each identify and weigh these strands, and whether comparing the two readings can make the story's socio-cultural structures easier to see. This project calls that comparison **synthetic reading**.

## 2. Research question (unchanged from the researcher's document)
How does Sayantani Dasgupta's *The Party* represent the intersections of gender, sexuality, class and emotional vulnerability, and how can synthetic reading reveal these socio-cultural structures through human–AI comparative literary analysis?

No modification was made. The question is workable as written; the only operational decision is that "intersections" is examined in Step 6 as shared evidence between thematic dimensions and interpreted in Step 7 (`research/interpretation_step7.md`).

## 3. Objectives
1. Divide the story into four blocks and document the partial reading (the highlighted opening of each block).
2. Record the researcher's preliminary (human) themes per block and her full-text interpretation, and test them against the full text.
3. Build a clean, reproducible corpus and preprocessing pipeline.
4. Specify a reusable LLM prompt that demands exact textual evidence and distinguishes explicit evidence from inference.
5. Produce a validated structured extraction (JSON) and keep human and AI findings separate.
6. Visualise distribution, frequency, co-occurrence, human–AI agreement and the intersection of four dimensions.
7. Interpret the patterns through the selected theories and answer the research question.

## 4. Approach
**Qualitative and interpretive.** Reading is treated as situated interpretation, not measurement. Themes are coded in a way close to reflexive thematic analysis (Braun & Clarke, 2006): the codes are interpretive, tied to specific evidence, and open to revision.

**Computational literary analysis.** Computation is used to organise and compare interpretations (counts of evidence items, shared-paragraph co-occurrence, agreement tables), in the spirit of algorithmic criticism (Ramsay, 2011). Word frequency is *not* used as evidence of a theme. Counts always refer to verified quotations attached to interpretive themes.

**Theoretical frameworks (selected, not exhaustive).**
| Framework | Why it is relevant to this story |
|---|---|
| Intersectionality (Crenshaw, 1989, 1991) | The narrator's position is shaped by salary, gender and sexuality together; treating them separately would miss how class envy and bodily self-surveillance are linked. |
| Gender performativity (Butler, 1990) | Mahesh's staged authority, Tanu's devotion and the narrator's body-checking read as repeated, regulated performances. |
| Heteronormativity / queer theory (Rich, 1980; Sedgwick, 1990; Warner, 1991) | The narrator can only imagine desire for a woman as "if you were a man", and Mahesh cannot accept his wife's past. |
| Cultural capital (Bourdieu, 1984, 1986) | Taste, intellectual talk and furnishing work as display; hospitality is a status performance. |
| Affect theory (Ahmed, 2004) | Shame, envy and disgust circulate between characters and attach to objects (food, bodies, the mother's remark). |
| Feminist and queer literary criticism | Provide the reading practices for the above (attention to who speaks, whose labour is invisible, what is closeted). |

In Steps 1–6 the frameworks only shaped the coding categories (the four dimensions: gender, sexuality, class, emotional vulnerability). In Step 7 they are used to interpret: each interpretive claim names the figure it starts from, the verified passages it rests on and the theory that frames it. Crenshaw's intersectionality is used in an extended sense (its structural insight, not its original legal context), and the Euro-American frames are flagged as a limitation.

## 5. Researcher positionality and reflexivity
The researcher is an MA Digital Humanities student reading a story in English set in contemporary New Delhi, from within the Indian academic and social context the story depicts. That context helps with reading details (a dhaba, Hindi films, Hauz Khas, the expectations around marriage and pregnancy) but it also carries assumptions about class, marriage and sexuality that can shape what is noticed. The researcher's preliminary themes and her full-text interpretation were written before the AI extraction; they are kept unchanged so that the comparison is honest. Choices that depend on judgment (the mapping of the researcher's key phrases to canonical themes, the coding of her full-text interpretation, the dimension tags) are documented in the data files so that they can be challenged.

## 6. Human reading versus AI-assisted reading
| | Human reading | AI-assisted reading |
|---|---|---|
| Strength | Situated knowledge, ethical judgment, sensitivity to tone | Systematic coverage of every paragraph, consistent coding, explicit evidence |
| Risk | Selective attention, impressionistic claims | Hallucinated quotations, flattened ambiguity, bias from training data |
| Safeguard here | Partial reading is documented; claims are tied to passages | Every quotation is machine-checked against the corpus; inference is labelled |

The AI extraction was done by Claude (claude-sonnet-5-5). `Theme_JSON.py` also contains a route for running the same prompt with a local model through Ollama.

## 7. Pipeline
1. `preprocessing/preprocess.py` — cleans text, preserves paragraphs, segments sentences, tokenises and counts.
2. `partial_reading/extract_highlights.py` — reads the yellow-highlighted passages from the researcher's .docx, maps them to paragraph IDs and checks them against the corpus.
3. `partial_reading/make_partial_reading.py` — writes the partial-reading record (observations from the highlighted passages only).
4. `extraction/extract_human_interpretation.py` — extracts the researcher's full-text interpretation from the .docx.
5. `prompts/prompt.txt` — reusable extraction prompt.
6. `extraction/Theme_JSON.py` — holds the AI extraction and the coding of the human interpretation, validates schema, quotations and human excerpts, writes `results/theme_extraction.json`.
7. `visualization/visualization.py` — five figures plus `results/figure_data.json`.
8. `interpretation/appetite_check.py` — Step 7 supporting check: tests whether a close-reading hypothesis (class and sexuality meet through the language of appetite) shows up lexically. It does not (base-rate result), which is reported as such.
9. `visualization/build_site.py` — assembles `index.html` from the above (so numbers on the page come from the data files) and verifies every Step 7 quotation against the corpus.

## 8. Ethics and limitations
- **Partial reading:** the highlighted passages are the opening of each block (27% of the words). First impressions from openings can over-weight how a block begins: in Block 2, only 2 of the researcher's 10 key words are visible in the highlighted passage.
- **Hallucination:** quotations are verified; interpretations are not "verified" and remain arguments.
- **Bias:** LLM readings of gender, sexuality and class in Indian settings may reflect Western or English-language training data.
- **Evidence type:** `explicit`/`inferential` labels describe the quotation. Almost all quotations are explicit, but the themes they support are interpretive. Count of "explicit" evidence must not be read as "uncontested theme".
- **Dimension tags** are fixed per theme, so the intersection figure reflects the coding scheme as well as the story.
- **Small corpus:** one story of about 4,300 words; counts describe this extraction, not general patterns.
- **Copyright:** the story is a copyrighted work. The corpus file was supplied by the researcher for study. If the repository is public, replace `corpus/The_Party.txt` with a link or keep the repository private (see README).

## References
See the References section of `index.html` (kept in one place to avoid divergence).
